# SiftNodes — dark hosting theme (storefront + admin console)

A complete, modern **black/dark theme** for a coin-based hosting store, built on Express + SQLite.
No `layout.ejs` anywhere — every page starts with a header partial and ends with a footer partial:

```ejs
<%- include('../partials/header') %>        <!-- or ../partials/admin-header -->
...
<%- include('../partials/footer') %>        <!-- or ../partials/admin-footer -->
```

## Run it

```bash
npm install
npm start            # http://localhost:3000
```

| Area | Login | Password |
|---|---|---|
| Storefront (customer) | `demo@unixservice.in` | `password123` |
| Admin console | `admin@unixservice.in` | `password123` |

> `DEMO_MODE=true` (default) instantly credits coin top-ups so you can test checkout.
> Set `DEMO_MODE=false` to keep them `pending` for manual verification like production.

The SQLite database (`hosting.db`) is created and seeded automatically on first boot with
4 categories, 10 plans, 7 reviews (one awaiting moderation), coupons (`UNIX25`, `LAUNCH100`),
9 orders across every status, 4 support tickets, 4 coin transactions and 14 days of analytics
traffic. Delete `hosting.db` to reseed from scratch.

## Storefront pages

| Route | View | Notes |
|---|---|---|
| `/view` | `users/view.ejs` | Landing: hero, animated stats, categories, plans, features, steps, testimonials, FAQ |
| `/products` | `users/products.ejs` | Catalogue with search, category filter, sorting, pagination, mobile filter drawer |
| `/c/:slug` | `users/products.ejs` | Same catalogue scoped to a category |
| `/products/:id` | `users/product-detail.ejs` | Live billing switcher, coupon validation, specs, reviews + rating form, related plans |
| `/login` · `/register` | `users/login.ejs` · `users/register.ejs` | Split-screen auth, validation, welcome coins |
| `/dashboard` | `users/dashboard.ejs` | Wallet, stat cards, recent orders, saved plans, tickets, quick actions |
| `/store` | `users/store.ejs` | Coin packs, UPI QR modal, screenshot upload, transaction ledger |
| `/orders` · `/orders/:id` · `/orders/:id/invoice` | `users/orders.ejs` · `order-detail.ejs` · `invoice.ejs` | Status tabs, pagination, service details, printable invoice |
| `/tickets` · `/tickets/new` · `/tickets/:id` | `users/tickets.ejs` · `ticket-new.ejs` · `ticket-view.ejs` | Support centre, SLA badges, attachments, threaded replies |
| `/profile` · `/profile/security` | `users/profile.ejs` · `security.ejs` | Personal + billing details, password change with strength meter |
| `/legal` · `/maintenance` | `users/legal.ejs` · `maintenance.ejs` | Policy pages with sticky TOC, maintenance holding page |
| `*` | `errors/404.ejs`, `errors/500.ejs` | Error pages |

## Admin console

Every admin page includes `partials/admin-header.ejs` (fixed sidebar, sticky top bar, badges,
toasts) and `partials/admin-footer.ejs`. The shell collapses to an off-canvas drawer below 960px.

| Route | View | Notes |
|---|---|---|
| `/admin/login` | `admin/admin-login.ejs` | Standalone split-screen sign-in (administrators only) |
| `/admin/dashboard` | `admin/dashboard.ejs` | Revenue/orders/customer/visitor KPIs, 7-day revenue + traffic charts, attention strip, recent orders, newest users, latest tickets, best sellers |
| `/admin/analytics` | `admin/analytics.ejs` | Date-range sessions chart (server-rendered SVG), top pages, countries, browsers, peak hours, latest sessions, CSV export, raw JSON |
| `/admin/orders` · `/admin/orders/:id` | `admin/orders.ejs` · `order-detail.ejs` | Status tabs with counts, search, detail page with billing summary, provisioned product, timeline, status update, guarded delete |
| `/admin/products` (+`new`, `:id/edit`, `:id/notes`) | `admin/products.ejs`, `product-new.ejs`, `product-edit.ejs`, `product-notes.ejs` | Catalogue table, full plan form (specs, features, 3 price points, image, visibility), private notes per product |
| `/admin/categories` (+`new`, `:id/edit`) | `admin/categories.ejs`, `category-new.ejs`, `category-edit.ejs` | Card grid with accent/icon preview, sort order, image, visibility |
| `/admin/users` (+`new`, `:id`) | `admin/users.ejs`, `user-new.ejs`, `user-detail.ejs` | Search + role filters, profile editor, coin credit/debit with reason, password reset, guarded delete, order/ticket/ledger history |
| `/admin/coin-transactions` | `admin/coin-transactions.ejs` | UPI top-up queue, verify (credits coins) or reject with reason |
| `/admin/coin-packages` (+`new`, `:id/edit`) | `admin/coin-packages.ejs`, `coin-package-new.ejs`, `coin-package-edit.ejs` | Bundle cards with per-coin rate, best-value badge, sold count |
| `/admin/coupons` (+`new`, `:id/edit`) | `admin/coupons.ejs`, `coupon-new.ejs`, `coupon-edit.ejs` | All/active/expired tabs, usage progress, copy code, expiry |
| `/admin/reviews` | `admin/reviews.ejs` | Moderation queue, star breakdown, approve/delete |
| `/admin/tickets` (+`stats`, `:id`) | `admin/tickets.ejs`, `ticket-stats.ejs`, `ticket-view.ejs` | Status/department/priority filters, unread badges, SLA state, thread + internal notes, canned responses, assignment, delete |
| `/admin/settings` | `admin/settings.ejs` | Site identity, contact email, currency label/symbol, UPI id, logo/favicon uploads, maintenance mode with message |

Admin routes live in `routes/admin.js` and are mounted from `app.js`. Nav badges
(`pendingOrders`, `pendingTransactions`, `unreadTickets`, `pendingReviews`) are computed in a
small `/admin` middleware, so they update on every page.

## Assets

```
public/css/style.css        ← one stylesheet: tokens, storefront components, admin console (§29),
                              responsive, print
public/js/app.js            ← storefront IIFE: drawer, search, dropdown, toasts, coupon AJAX,
                              counters, reveal animations, password meter, uploads, store modal
public/js/admin.js          ← admin shell: sidebar drawer, reply/note tabs, reject-row toggles,
                              date-range shortcuts, colour picker readout, image previews
views/partials/icons.ejs    ← shared inline SVG sprite (50+ symbols, no icon font)
views/partials/header.ejs   ← storefront <head>, top bar, nav + mega menu, mobile drawer, toasts
views/partials/footer.ejs   ← storefront CTA band, full footer, back-to-top
views/partials/admin-header.ejs ← admin <head>, sidebar nav with badge counts, top bar, toasts
views/partials/admin-footer.ejs ← closes the admin shell, loads app.js + admin.js
```

Everything is self-contained: **no CDN, no external fonts, no images** — the logo, favicon,
icons and coin artwork are inline SVG/data URIs, so the UI looks identical offline.

## Design system

- **Palette:** `#050507` base, layered panels, violet `#8b5cf6` → cyan `#22d3ee` gradient accent,
  semantic green/amber/red for statuses.
- **Type:** system UI stack, tight headings (-0.045em), mono for IDs and terminal blocks.
- **Motion:** hero console typing cursor, floating cards, reveal-on-scroll with a safety fallback,
  count-up numbers, animated charts, hover lifts, pulsing status dots. All respect
  `prefers-reduced-motion`.
- **Mobile:** storefront slide-in drawer + filter sheet; admin off-canvas sidebar; tables shed
  secondary columns at 640px; full-width CTAs and safe-area padding. Tested at 390 × 844.

## Notes for merging into your existing app

1. Copy `views/` and `public/css/style.css`, `public/js/app.js`, `public/js/admin.js`.
2. Keep your existing `app.js`; templates only need the locals you already provide
   (`settings`, `user`, `isLoggedIn`, `currencyName`, `navCategories`, `success`/`error`,
   `moment`, `h`).
   - `coinIcon` — inline SVG data URI (see `COIN_ICON` in `app.js`) so prices never show a
     missing-glyph box.
   - `pageTitle`/`title`, `activePage` — used for the document title and sidebar highlighting.
   - Admin pages additionally read `pendingOrders`, `pendingTransactions`, `unreadTickets`,
     `pendingReviews` (fall back to 0 if absent) and the locals listed in each route.
3. `routes/admin.js` is a complete reference implementation against the seeded schema; mount it
   with `require('./routes/admin')(app, deps)` or port the handlers into your router.
4. The coupon box calls `POST /api/coupon` (`{ code, productId, cycle }` → `{ ok, type, value, … }`).
5. Uploads for product/category images, site logo/favicon and ticket screenshots live in
   `public/uploads/` (created automatically).

## Extra polish worth knowing

- Coupon `UNIX25` (25% off) and `LAUNCH100` (100 coins off) are seeded and validated server-side.
- `/c/:cat/:id` legacy links 301-redirect to `/products/:id`.
- The invoice page swaps to a clean light layout and is print/PDF ready.
- Admin verify credits coins **once**; rejections keep the audit trail in `notes`.
- Deleting an active order or a user with live orders is blocked — suspend/cancel first.
- Analytics are cookie-free; bots are filtered out of every number shown.
- Maintenance mode blocks the storefront (`503` + branded page) while administrators bypass it.
