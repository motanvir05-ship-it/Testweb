/* SiftNodes — admin console interactions */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  document.addEventListener('DOMContentLoaded', function () {
    /* ---------- off-canvas sidebar ---------- */
    var sidebar = $('#adminSidebar');
    var scrim = $('#adminScrim');
    var menuBtn = $('#adminMenuBtn');
    var sideClose = $('#adminSideClose');

    function openSide() {
      if (!sidebar) return;
      sidebar.classList.add('is-open');
      if (scrim) { scrim.hidden = false; requestAnimationFrame(function () { scrim.classList.add('is-open'); }); }
      document.body.classList.add('drawer-locked');
      if (menuBtn) menuBtn.setAttribute('aria-expanded', 'true');
    }
    function closeSide() {
      if (!sidebar) return;
      sidebar.classList.remove('is-open');
      if (scrim) {
        scrim.classList.remove('is-open');
        window.setTimeout(function () { scrim.hidden = true; }, 280);
      }
      document.body.classList.remove('drawer-locked');
      if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
    }
    if (menuBtn) menuBtn.addEventListener('click', openSide);
    if (sideClose) sideClose.addEventListener('click', closeSide);
    if (scrim) scrim.addEventListener('click', closeSide);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeSide();
    });
    $$('#adminSidebar .admin-nav-link').forEach(function (link) {
      link.addEventListener('click', function () { if (window.innerWidth <= 960) closeSide(); });
    });

    /* ---------- canned responses ---------- */
    var canned = $('#cannedSelect');
    var replyArea = $('#replyMessage');
    if (canned && replyArea) {
      canned.addEventListener('change', function () {
        var option = canned.options[canned.selectedIndex];
        if (!option || !option.value) return;
        var text = option.getAttribute('data-text') || '';
        replyArea.value = text;
        replyArea.focus();
        canned.selectedIndex = 0;
      });
    }

    /* ---------- reply / note tabs ---------- */
    var tabs = $$('[data-tab-btn]');
    if (tabs.length) {
      tabs.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var target = btn.getAttribute('data-tab-btn');
          tabs.forEach(function (b) {
            b.classList.toggle('is-active', b === btn);
            b.setAttribute('aria-selected', b === btn ? 'true' : 'false');
          });
          $$('[data-tab-panel]').forEach(function (panel) {
            panel.hidden = panel.getAttribute('data-tab-panel') !== target;
          });
        });
      });
    }

    /* ---------- inline danger toggles ---------- */
    $$('[data-toggle-target]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var el = document.getElementById(btn.getAttribute('data-toggle-target'));
        if (el) el.hidden = !el.hidden;
      });
    });

    /* ---------- range shortcut buttons ---------- */
    $$('[data-range-days]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var days = parseInt(btn.getAttribute('data-range-days'), 10);
        var to = new Date();
        var from = new Date();
        from.setDate(to.getDate() - (days - 1));
        var pad = function (n) { return String(n).padStart(2, '0'); };
        var fmt = function (d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
        var fromInput = $('#dateFrom');
        var toInput = $('#dateTo');
        if (fromInput) fromInput.value = fmt(from);
        if (toInput) toInput.value = fmt(to);
        if (fromInput && fromInput.form) fromInput.form.submit();
      });
    });

    /* ---------- copy to clipboard fallback for admin (data-copy handled in app.js) ---------- */
    $$('[data-copy-text]').forEach(function (el) {
      el.addEventListener('click', function () {
        var text = el.getAttribute('data-copy-text');
        if (navigator.clipboard) navigator.clipboard.writeText(text);
        var old = el.textContent;
        el.textContent = 'Copied';
        window.setTimeout(function () { el.textContent = old; }, 1300);
      });
    });

    /* ---------- accent colour hex readout ---------- */
    var accentInput = $('#cAccent');
    var accentHex = $('#cAccentHex');
    if (accentInput && accentHex) {
      accentInput.addEventListener('input', function () { accentHex.textContent = accentInput.value; });
    }

    /* ---------- image preview on file inputs ---------- */
    $$('[data-image-preview]').forEach(function (input) {
      var img = document.getElementById(input.getAttribute('data-image-preview'));
      if (!img) return;
      input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        if (!file) return;
        img.src = URL.createObjectURL(file);
        img.hidden = false;
      });
    });
  });
})();
