/* SiftNodes — UI interactions */
(function () {
  'use strict';

  var $ = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  document.addEventListener('DOMContentLoaded', function () {

    /* ---------- sticky header state ---------- */
    var header = $('#siteHeader');
    var toTop = $('#toTop');
    function onScroll() {
      var y = window.scrollY || window.pageYOffset;
      if (header) header.classList.toggle('is-scrolled', y > 12);
      if (toTop) toTop.classList.toggle('is-visible', y > 620);
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    if (toTop) {
      toTop.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }

    /* ---------- announcement bar ---------- */
    var topbar = $('#topbar');
    if (topbar) {
      var dismissed = false;
      try { dismissed = localStorage.getItem('unix.topbar') === 'off'; } catch (e) {}
      if (dismissed) topbar.classList.add('is-hidden');
      var closeTop = $('#topbarClose');
      if (closeTop) {
        closeTop.addEventListener('click', function () {
          topbar.classList.add('is-hidden');
          try { localStorage.setItem('unix.topbar', 'off'); } catch (e) {}
        });
      }
    }

    /* ---------- mobile drawer ---------- */
    var drawer = $('#mobileDrawer');
    var scrim = $('#drawerScrim');
    var menuBtn = $('#menuBtn');
    var drawerClose = $('#drawerClose');

    function openDrawer() {
      if (!drawer) return;
      drawer.hidden = false;
      scrim.hidden = false;
      // allow the browser a frame to apply layout before transitioning
      requestAnimationFrame(function () {
        drawer.classList.add('is-open');
        scrim.classList.add('is-open');
      });
      drawer.setAttribute('aria-hidden', 'false');
      document.body.classList.add('drawer-locked');
      if (menuBtn) menuBtn.setAttribute('aria-expanded', 'true');
    }
    function closeDrawer() {
      if (!drawer) return;
      drawer.classList.remove('is-open');
      scrim.classList.remove('is-open');
      drawer.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('drawer-locked');
      if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
      window.setTimeout(function () {
        if (!drawer.classList.contains('is-open')) {
          drawer.hidden = true;
          scrim.hidden = true;
        }
      }, 350);
    }
    if (menuBtn) menuBtn.addEventListener('click', openDrawer);
    if (drawerClose) drawerClose.addEventListener('click', closeDrawer);
    if (scrim) scrim.addEventListener('click', closeDrawer);
    $$('#mobileDrawer a').forEach(function (link) {
      link.addEventListener('click', function () { closeDrawer(); });
    });

    /* ---------- user dropdown ---------- */
    var userBtn = $('#userBtn');
    var userMenu = $('#userMenu');
    if (userBtn && userMenu) {
      userBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = userMenu.classList.toggle('is-open');
        userBtn.classList.toggle('is-open', open);
        userBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
      document.addEventListener('click', function (e) {
        if (!userMenu.contains(e.target) && !userBtn.contains(e.target)) {
          userMenu.classList.remove('is-open');
          userBtn.classList.remove('is-open');
          userBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }

    /* ---------- search overlay ---------- */
    var searchOverlay = $('#searchOverlay');
    var searchInput = $('#searchInput');
    var searchOpen = $('#searchOpen');
    var searchClose = $('#searchClose');

    function openSearch() {
      if (!searchOverlay) return;
      searchOverlay.hidden = false;
      document.body.classList.add('drawer-locked');
      window.setTimeout(function () { if (searchInput) searchInput.focus(); }, 60);
    }
    function closeSearch() {
      if (!searchOverlay) return;
      searchOverlay.hidden = true;
      document.body.classList.remove('drawer-locked');
    }
    if (searchOpen) searchOpen.addEventListener('click', openSearch);
    if (searchClose) searchClose.addEventListener('click', closeSearch);
    if (searchOverlay) {
      searchOverlay.addEventListener('click', function (e) {
        if (e.target === searchOverlay) closeSearch();
      });
    }
    document.addEventListener('keydown', function (e) {
      if ((e.metaKey || e.ctrlKey) && String(e.key).toLowerCase() === 'k') {
        e.preventDefault();
        openSearch();
      }
      if (e.key === 'Escape') {
        closeSearch();
        closeDrawer();
        if (userMenu) {
          userMenu.classList.remove('is-open');
          if (userBtn) {
            userBtn.classList.remove('is-open');
            userBtn.setAttribute('aria-expanded', 'false');
          }
        }
      }
    });

    /* ---------- toasts ---------- */
    $$('.toast').forEach(function (toast, i) {
      var remove = function () {
        toast.classList.add('is-leaving');
        window.setTimeout(function () { toast.remove(); }, 320);
      };
      var x = $('.toast-x', toast);
      if (x) x.addEventListener('click', remove);
      window.setTimeout(remove, 6500 + i * 700);
    });

    /* ---------- copy to clipboard ---------- */
    $$('[data-copy]').forEach(function (el) {
      el.addEventListener('click', function () {
        var text = el.getAttribute('data-copy');
        var done = function () {
          el.classList.add('is-copied');
          var original = el.innerHTML;
          el.innerHTML = 'Copied!';
          window.setTimeout(function () {
            el.innerHTML = original;
            el.classList.remove('is-copied');
          }, 1600);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(done).catch(function () {});
        } else {
          var ta = document.createElement('textarea');
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand('copy'); done(); } catch (e) {}
          ta.remove();
        }
      });
    });

    /* ---------- reveal on scroll ---------- */
    var revealEls = $$('[data-reveal]');
    if ('IntersectionObserver' in window && revealEls.length) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.remove('reveal-pending');
            entry.target.classList.add('in-view');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.05, rootMargin: '60px 0px -30px 0px' });
      revealEls.forEach(function (el) {
        var rect = el.getBoundingClientRect();
        // anything already on (or near) the first screen is shown straight away
        if (rect.top < (window.innerHeight || 800) * 1.15) {
          el.classList.add('in-view');
        } else {
          el.classList.add('reveal-pending');
          io.observe(el);
        }
      });
      // safety net: if the observer never reports (odd embeds), reveal everything
      window.setTimeout(function () {
        revealEls.forEach(function (el) {
          if (!el.classList.contains('in-view')) {
            el.classList.remove('reveal-pending');
            el.classList.add('in-view');
          }
        });
      }, 6000);
    } else {
      revealEls.forEach(function (el) { el.classList.add('in-view'); });
    }

    /* ---------- animated counters ---------- */
    var counters = $$('[data-count]');
    function animateCounter(el) {
      var target = parseFloat(el.getAttribute('data-count'));
      var decimals = (String(el.getAttribute('data-count')).split('.')[1] || '').length;
      var suffix = el.getAttribute('data-suffix') || '';
      var prefix = el.getAttribute('data-prefix') || '';
      var duration = 1300;
      var start = null;
      function step(ts) {
        if (!start) start = ts;
        var progress = Math.min((ts - start) / duration, 1);
        var eased = 1 - Math.pow(1 - progress, 3);
        var value = target * eased;
        el.textContent = prefix + value.toLocaleString('en-IN', {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals
        }) + suffix;
        if (progress < 1) window.requestAnimationFrame(step);
      }
      window.requestAnimationFrame(step);
    }
    if (counters.length) {
      if ('IntersectionObserver' in window) {
        var cio = new IntersectionObserver(function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              animateCounter(entry.target);
              cio.unobserve(entry.target);
            }
          });
        }, { threshold: 0.5 });
        counters.forEach(function (el) { cio.observe(el); });
      } else {
        counters.forEach(animateCounter);
      }
    }

    /* ---------- password visibility ---------- */
    $$('[data-pw-toggle]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var target = document.getElementById(btn.getAttribute('data-pw-toggle'));
        if (!target) return;
        var show = target.type === 'password';
        target.type = show ? 'text' : 'password';
        btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        btn.classList.toggle('is-showing', show);
      });
    });

    /* ---------- password strength ---------- */
    var pwInput = $('#newPassword');
    var pwBar = $('#pwBar');
    var pwLabel = $('#pwLabel');
    if (pwInput && pwBar) {
      pwInput.addEventListener('input', function () {
        var v = pwInput.value;
        var score = 0;
        if (v.length >= 8) score++;
        if (v.length >= 12) score++;
        if (/[A-Z]/.test(v) && /[a-z]/.test(v)) score++;
        if (/[0-9]/.test(v)) score++;
        if (/[^A-Za-z0-9]/.test(v)) score++;
        var pct = Math.min(100, score * 20);
        var colors = ['#fb7185', '#fb7185', '#fbbf24', '#fbbf24', '#34d399', '#34d399'];
        var labels = ['Too short', 'Weak', 'Weak', 'Fair', 'Strong', 'Excellent'];
        pwBar.style.width = pct + '%';
        pwBar.style.background = colors[score] || '#34d399';
        if (pwLabel) pwLabel.textContent = v ? labels[score] || 'Excellent' : 'Enter a password';
      });
    }

    /* ---------- file inputs ---------- */
    $$('[data-file-input]').forEach(function (input) {
      var targetId = input.getAttribute('data-file-input');
      var list = document.getElementById(targetId);
      var zone = input.closest('.dropzone');
      var label = zone ? $('[data-file-label]', zone) : null;
      var defaultLabel = label ? label.textContent : '';

      function render() {
        if (!list) return;
        list.innerHTML = '';
        var files = Array.prototype.slice.call(input.files || []);
        if (label) label.textContent = files.length ? files.length + ' file' + (files.length > 1 ? 's' : '') + ' selected' : defaultLabel;
        files.forEach(function (file) {
          var chip = document.createElement('div');
          chip.className = 'file-chip';
          var name = document.createElement('span');
          name.className = 'name';
          name.textContent = file.name;
          var size = document.createElement('span');
          size.className = 'size';
          size.textContent = (file.size / 1024 / 1024 >= 1)
            ? (file.size / 1024 / 1024).toFixed(1) + ' MB'
            : Math.max(1, Math.round(file.size / 1024)) + ' KB';
          chip.appendChild(name);
          chip.appendChild(size);
          list.appendChild(chip);
        });
      }
      input.addEventListener('change', render);
      if (zone) {
        ['dragenter', 'dragover'].forEach(function (ev) {
          zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add('is-drag'); });
        });
        ['dragleave', 'drop'].forEach(function (ev) {
          zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.remove('is-drag'); });
        });
      }
    });

    /* ---------- confirm actions ---------- */
    $$('form[data-confirm]').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
      });
    });
    $$('[data-confirm-click]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        if (!window.confirm(el.getAttribute('data-confirm-click'))) e.preventDefault();
      });
    });

    /* ---------- filter auto-submit ---------- */
    $$('[data-auto-submit]').forEach(function (el) {
      el.addEventListener('change', function () {
        if (el.form) el.form.submit();
      });
    });

    /* ---------- qty-safe number inputs (data-min) ---------- */
    $$('input[data-min]').forEach(function (input) {
      input.addEventListener('blur', function () {
        var min = parseFloat(input.getAttribute('data-min'));
        if (input.value !== '' && parseFloat(input.value) < min) input.value = min;
      });
    });

    /* ---------- mobile filters ---------- */
    var filtersPanel = $('#filtersPanel');
    var filterToggles = $$('[data-filter-toggle]');
    if (filtersPanel && filterToggles.length) {
      filterToggles.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var open = filtersPanel.classList.toggle('is-open');
          filterToggles.forEach(function (b) {
            b.setAttribute('aria-expanded', open ? 'true' : 'false');
            var label = $('[data-filter-label]', b);
            if (label) label.textContent = open ? 'Hide filters' : 'Filters';
            else b.textContent = open ? 'Hide filters' : 'Show filters';
          });
          if (open) filtersPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
      });
    }

    /* ---------- newsletter ---------- */
    var newsletterForm = $('#newsletterForm');
    if (newsletterForm) {
      newsletterForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = $('input[type="email"]', newsletterForm);
        var note = $('#newsletterNote');
        if (!input || !note) return;
        var value = input.value.trim();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          note.textContent = 'Please enter a valid email address.';
          note.classList.remove('is-ok');
          return;
        }
        note.textContent = 'You are on the list — welcome aboard!';
        note.classList.add('is-ok');
        input.value = '';
      });
    }

    /* ---------- product billing cycle + coupon ---------- */
    var cycleSwitch = $('[data-cycle-switch]');
    var purchaseForm = $('#purchaseForm');
    if (cycleSwitch && purchaseForm) {
      var amountEl = $('#priceAmount');
      var perEl = $('#pricePer');
      var noteEl = $('#priceNote');
      var sumSubtotal = $('#sumSubtotal');
      var sumTotal = $('#sumTotal');
      var sumDiscount = $('#sumDiscount');
      var discountRow = $('#discountRow');
      var discountCode = $('#discountCode');
      var cycleInput = $('#cycleInput');
      var balance = parseFloat(purchaseForm.getAttribute('data-balance') || '0');
      var couponEl = $('#couponCode');
      var couponMsg = $('#couponMsg');
      var appliedCoupon = null;
      var coinSrc = purchaseForm.getAttribute('data-coin') || '';
      var coin = '<img class="ico-coin" src="' + coinSrc + '" alt="">';

      function money(n) { return Number(n).toLocaleString('en-IN'); }

      function currentPrice() {
        var active = $('button.is-active', cycleSwitch);
        return active ? parseFloat(active.getAttribute('data-price') || '0') : 0;
      }

      function refresh(updateNote) {
        var active = $('button.is-active', cycleSwitch);
        if (!active || !amountEl) return;
        var price = parseFloat(active.getAttribute('data-price') || '0');
        var cycle = active.getAttribute('data-cycle');
        var months = cycle === 'yearly' ? 12 : cycle === 'quarterly' ? 3 : 1;
        amountEl.textContent = money(price);
        if (perEl) perEl.textContent = active.getAttribute('data-per') || 'per month';
        if (noteEl && updateNote !== false) {
          var monthlyEquivalent = Math.round(price / months);
          noteEl.innerHTML = months > 1
            ? 'Works out to <span class="save-amt">' + money(monthlyEquivalent) + ' ' + coin + ' / month</span> — billed ' + (months === 12 ? 'yearly' : 'quarterly') + '.'
            : 'Billed monthly. Cancel anytime.';
        }
        if (cycleInput) cycleInput.value = cycle;
        if (sumSubtotal) sumSubtotal.innerHTML = money(price) + ' ' + coin;
        var discount = 0;
        if (appliedCoupon) {
          discount = appliedCoupon.type === 'percent'
            ? Math.round(price * (Math.min(100, appliedCoupon.value) / 100))
            : Math.min(appliedCoupon.value, price);
          if (sumDiscount) sumDiscount.innerHTML = '− ' + money(discount) + ' ' + coin;
          if (discountRow) discountRow.hidden = false;
          if (discountCode) discountCode.textContent = appliedCoupon.code;
        } else if (discountRow) {
          discountRow.hidden = true;
        }
        var total = Math.max(0, price - discount);
        if (sumTotal) sumTotal.innerHTML = money(total) + ' ' + coin;
        var submit = $('button[type="submit"]', purchaseForm);
        if (submit) {
          if (balance > 0 && total > balance) {
            submit.classList.add('is-over-budget');
            submit.innerHTML = 'Not enough coins — top up';
          } else {
            submit.classList.remove('is-over-budget');
          }
        }
      }

      $$('button[data-cycle]', cycleSwitch).forEach(function (btn) {
        btn.addEventListener('click', function () {
          $$('button[data-cycle]', cycleSwitch).forEach(function (b) { b.classList.remove('is-active'); });
          btn.classList.add('is-active');
          refresh();
        });
      });

      var applyBtn = $('#applyCoupon');
      function applyCoupon(code) {
        if (!code) { if (couponMsg) couponMsg.textContent = ''; return; }
        if (couponMsg) { couponMsg.textContent = 'Checking code…'; couponMsg.style.color = ''; }
        var active = $('button.is-active', cycleSwitch);
        var cycle = active ? active.getAttribute('data-cycle') : 'monthly';
        var productId = purchaseForm.getAttribute('data-product');
        fetch('/api/coupon', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ code: code, productId: productId, cycle: cycle })
        }).then(function (r) { return r.json(); }).then(function (data) {
          if (data.ok) {
            appliedCoupon = { code: data.code, type: data.type, value: data.value };
            if (couponMsg) { couponMsg.textContent = data.label; couponMsg.style.color = '#34d399'; }
            refresh(false);
          } else {
            appliedCoupon = null;
            if (couponEl) couponEl.value = '';
            if (couponMsg) { couponMsg.textContent = data.error || 'That code is not valid.'; couponMsg.style.color = '#fb7185'; }
            refresh(false);
          }
        }).catch(function () {
          if (couponMsg) { couponMsg.textContent = 'Could not check that code — try again.'; couponMsg.style.color = '#fb7185'; }
        });
      }
      if (applyBtn) {
        applyBtn.addEventListener('click', function () {
          applyCoupon(couponEl ? couponEl.value.trim().toUpperCase() : '');
        });
      }
      if (couponEl) {
        couponEl.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') {
            e.preventDefault();
            applyCoupon(couponEl.value.trim().toUpperCase());
          }
        });
      }
      refresh();
    }

    /* ---------- like button ---------- */
    $$('[data-like-btn]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var productId = btn.getAttribute('data-like-btn');
        btn.disabled = true;
        fetch('/products/' + productId + '/like', { method: 'POST', headers: { 'Accept': 'application/json' } })
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (typeof data.liked === 'boolean') {
              btn.classList.toggle('is-liked', data.liked);
              var label = $('[data-like-label]', btn);
              if (label) label.textContent = data.liked ? 'Saved' : 'Save';
            }
          })
          .catch(function () {})
          .finally(function () { btn.disabled = false; });
      });
    });

    /* ---------- copy current page URL ---------- */
    $$('[data-copy-url]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var url = window.location.href;
        var done = function () {
          var original = btn.innerHTML;
          btn.innerHTML = 'Link copied';
          window.setTimeout(function () { btn.innerHTML = original; }, 1500);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(done).catch(function () {});
        } else {
          var ta = document.createElement('textarea');
          ta.value = url;
          document.body.appendChild(ta);
          ta.select();
          try { document.execCommand('copy'); done(); } catch (e) {}
          ta.remove();
        }
      });
    });

    /* ---------- copy order id / UPI ---------- */
    $$('[data-copy-value]').forEach(function (el) {
      el.addEventListener('click', function () {
        var text = el.getAttribute('data-copy-value');
        if (navigator.clipboard) navigator.clipboard.writeText(text);
        var old = el.textContent;
        el.textContent = 'Copied';
        window.setTimeout(function () { el.textContent = old; }, 1400);
      });
    });

    /* ---------- store modal ---------- */
    var modal = $('#storeModal');
    if (modal) {
      var modalTitle = $('#modalPackageName');
      var modalCoins = $('#modalCoins');
      var modalPrice = $('#modalPrice');
      var modalPackage = $('#modalPackageId');
      var lastFocus = null;

      function openModal(card) {
        lastFocus = document.activeElement;
        var name = card.getAttribute('data-name');
        var coins = card.getAttribute('data-coins');
        var price = card.getAttribute('data-price');
        var id = card.getAttribute('data-id');
        if (modalTitle) modalTitle.textContent = name;
        if (modalCoins) modalCoins.textContent = Number(coins).toLocaleString('en-IN');
        if (modalPrice) modalPrice.textContent = '₹' + Number(price).toLocaleString('en-IN');
        if (modalPackage) modalPackage.value = id;
        modal.hidden = false;
        document.body.classList.add('drawer-locked');
        window.setTimeout(function () {
          var firstInput = $('#upiRef', modal);
          if (firstInput) firstInput.focus();
        }, 80);
      }
      function closeModal() {
        modal.hidden = true;
        document.body.classList.remove('drawer-locked');
        if (lastFocus) lastFocus.focus();
      }
      $$('[data-buy-package]').forEach(function (btn) {
        btn.addEventListener('click', function () { openModal(btn); });
      });
      $$('[data-close-modal]', modal).forEach(function (el) {
        el.addEventListener('click', closeModal);
      });
      modal.addEventListener('click', function (e) {
        if (e.target === modal) closeModal();
      });
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && !modal.hidden) closeModal();
      });
    }

    /* ---------- character counter ---------- */
    $$('[data-counter-for]').forEach(function (counter) {
      var input = document.getElementById(counter.getAttribute('data-counter-for'));
      if (!input) return;
      var max = input.getAttribute('maxlength') || 1000;
      var update = function () {
        counter.textContent = input.value.length + ' / ' + max;
      };
      input.addEventListener('input', update);
      update();
    });

    /* ---------- submit button loading state ---------- */
    $$('form[data-loading]').forEach(function (form) {
      form.addEventListener('submit', function () {
        var btn = form.querySelector('button[type="submit"]');
        if (btn) {
          btn.classList.add('is-loading');
          var label = btn.getAttribute('data-loading-label') || 'Working…';
          btn.textContent = label;
        }
      });
    });
  });
})();
