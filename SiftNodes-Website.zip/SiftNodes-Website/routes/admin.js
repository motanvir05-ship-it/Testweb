/**
 * Admin routes for SiftNodes.
 * Every view lives in views/admin/ and uses the same include pattern:
 *   <%- include('../partials/admin-header') %> ... <%- include('../partials/admin-footer') %>
 */
module.exports = function registerAdminRoutes(app, ctx) {
    const {
        dbGet, dbAll, runDb, helpers,
        getProduct, processProducts, getCategoryBySlug,
        requireAdmin, upload, categoryUpload, upsertSetting,
        uuidv4, moment, bcrypt, TICKET_CONFIG,
        calculateSLADueDate, slaStatus, COIN_ICON
    } = ctx;

    const perPage = 10;
    const safePage = (v) => Math.max(1, parseInt(v, 10) || 1);

    // Admin views must be able to open inactive products too, so this variant
    // skips the `p.isActive = 1` filter baked into the storefront getProduct().
    async function getAdminProduct(id) {
        const row = await dbGet(
            `SELECT p.*, c.name AS categoryName, c.slug AS categorySlug, c.icon AS categoryIcon, c.accent AS categoryAccent
             FROM products p LEFT JOIN categories c ON p.categoryId = c.id
             WHERE p.id = ?`, [id]);
        if (!row) return null;
        const [product] = await processProducts([row]);
        product.isLiked = false;
        const notes = await dbAll('SELECT note FROM product_notes WHERE productId = ? AND isActive = 1', [id]);
        product.note = notes.length ? notes[Math.floor(Math.random() * notes.length)].note : '';
        return product;
    }

    // ---------------------------------------------------------
    //  Shared admin locals (nav badges / global counters)
    // ---------------------------------------------------------
    app.use('/admin', async (req, res, next) => {
        try {
            const [pendingOrders, pendingTransactions, unreadTickets, pendingReviews] = await Promise.all([
                helpers.countRows('orders', "WHERE status = 'pending'"),
                helpers.countRows('coin_transactions', "WHERE status = 'pending'"),
                helpers.countRows('tickets', 'WHERE isReadAdmin = 0'),
                helpers.countRows('reviews', 'WHERE isApproved = 0')
            ]);
            res.locals.pendingOrders = pendingOrders;
            res.locals.pendingTransactions = pendingTransactions;
            res.locals.unreadTickets = unreadTickets;
            res.locals.pendingReviews = pendingReviews;
        } catch (err) {
            res.locals.pendingOrders = 0;
            res.locals.pendingTransactions = 0;
            res.locals.unreadTickets = 0;
            res.locals.pendingReviews = 0;
        }
        res.locals.adminNavBadges = {
            orders: res.locals.pendingOrders,
            'coin-transactions': res.locals.pendingTransactions,
            tickets: res.locals.unreadTickets,
            reviews: res.locals.pendingReviews
        };
        next();
    });

    // =========================================================
    //  AUTH
    // =========================================================
    app.get('/admin/login', (req, res) => {
        if (req.session.authorised && req.session.user && req.session.user.isAdmin) {
            return res.redirect('/admin/dashboard');
        }
        res.render('admin/admin-login', { title: 'Admin sign-in', activePage: 'admin-login' });
    });

    app.post('/admin/login', async (req, res, next) => {
        try {
            const { email, password, remember } = req.body;
            const user = await dbGet(
                'SELECT * FROM users WHERE email = ? AND isAdmin = 1 AND isActive = 1',
                [String(email || '').toLowerCase().trim()]
            );
            if (!user || !bcrypt.compareSync(String(password || ''), user.password)) {
                if (user) await runDb('UPDATE users SET loginAttempts = loginAttempts + 1, lastIp = ? WHERE id = ?', [req.ip, user.id]);
                req.flash('error', 'Those administrator credentials are not valid.');
                return res.redirect('/admin/login');
            }
            await runDb('UPDATE users SET loginAttempts = 0, lastLogin = CURRENT_TIMESTAMP, lastIp = ? WHERE id = ?', [req.ip, user.id]);
            req.session.authorised = true;
            req.session.user = {
                id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName,
                coins: user.coins, isAdmin: 1
            };
            if (remember === 'on') req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30;
            req.flash('success', `Signed in as administrator — welcome back, ${user.firstName}.`);
            res.redirect('/admin/dashboard');
        } catch (err) { next(err); }
    });

    app.get('/admin/logout', (req, res) => {
        req.session.destroy(() => {
            res.clearCookie('connect.sid');
            res.redirect('/admin/login');
        });
    });

    app.get('/admin', requireAdmin, (req, res) => res.redirect('/admin/dashboard'));

    // =========================================================
    //  DASHBOARD
    // =========================================================
    app.get('/admin/dashboard', requireAdmin, async (req, res, next) => {
        try {
            const today = moment().format('YYYY-MM-DD');
            const monthStart = moment().startOf('month').format('YYYY-MM-DD');
            const [
                totalUsers, totalProducts, totalOrders, activeOrders, totalTickets,
                openTickets, totalVisits, uniqueVisitors, totalReviews, approvedReviews,
                revenueRow, monthRevenueRow, visitsToday, newUsersMonth
            ] = await Promise.all([
                helpers.countRows('users'),
                helpers.countRows('products', 'WHERE isActive = 1'),
                helpers.countRows('orders'),
                helpers.countRows('orders', "WHERE status = 'active'"),
                helpers.countRows('tickets'),
                helpers.countRows('tickets', "WHERE status IN ('open','in_progress','on_hold')"),
                helpers.countRows('visits', 'WHERE is_bot = 0'),
                dbGet('SELECT COUNT(DISTINCT ip) AS c FROM visits WHERE is_bot = 0'),
                helpers.countRows('reviews'),
                helpers.countRows('reviews', 'WHERE isApproved = 1'),
                dbGet("SELECT SUM(price) AS total FROM orders WHERE status IN ('active','completed')"),
                dbGet("SELECT SUM(price) AS total FROM orders WHERE status IN ('active','completed') AND date(createdAt) >= ?", [monthStart]),
                helpers.countRows('visits', 'WHERE is_bot = 0 AND date(timestamp) = ?', [today]),
                helpers.countRows('users', 'WHERE date(createdAt) >= ?', [monthStart])
            ]);

            const recentOrders = await dbAll(
                `SELECT o.*, u.email AS userEmail, u.firstName, u.lastName
                 FROM orders o LEFT JOIN users u ON o.userId = u.id
                 ORDER BY o.createdAt DESC LIMIT 6`
            );
            const recentUsers = await dbAll('SELECT id, firstName, lastName, email, coins, isAdmin, isActive, createdAt FROM users ORDER BY createdAt DESC LIMIT 5');
            const recentTickets = await dbAll('SELECT * FROM tickets ORDER BY updatedAt DESC LIMIT 5');
            const topProducts = await dbAll(
                `SELECT productName, COUNT(*) AS orders, SUM(price) AS revenue
                 FROM orders GROUP BY productName ORDER BY orders DESC, revenue DESC LIMIT 5`
            );
            const revenueSeries = [];
            for (let i = 6; i >= 0; i--) {
                const day = moment().subtract(i, 'days');
                const row = await dbGet(
                    `SELECT SUM(price) AS total, COUNT(*) AS c FROM orders
                     WHERE status IN ('active','completed') AND date(createdAt) = ?`,
                    [day.format('YYYY-MM-DD')]
                );
                revenueSeries.push({
                    label: day.format('ddd'),
                    date: day.format('DD MMM'),
                    value: row && row.total ? row.total : 0,
                    orders: row ? row.c : 0
                });
            }
            const trafficSeries = [];
            for (let i = 6; i >= 0; i--) {
                const day = moment().subtract(i, 'days').format('YYYY-MM-DD');
                const c = await helpers.countRows('visits', 'WHERE is_bot = 0 AND date(timestamp) = ?', [day]);
                trafficSeries.push({ label: moment(day).format('ddd'), value: c });
            }
            const maxRevenue = Math.max(1, ...revenueSeries.map((r) => r.value));
            const maxTraffic = Math.max(1, ...trafficSeries.map((r) => r.value));

            res.render('admin/dashboard', {
                title: 'Admin dashboard',
                activePage: 'dashboard',
                stats: {
                    totalUsers,
                    totalProducts,
                    totalOrders,
                    activeOrders,
                    totalTickets,
                    openTickets,
                    totalVisits,
                    uniqueVisitors: uniqueVisitors ? uniqueVisitors.c : 0,
                    totalReviews,
                    approvedReviews,
                    revenue: revenueRow && revenueRow.total ? revenueRow.total : 0,
                    monthRevenue: monthRevenueRow && monthRevenueRow.total ? monthRevenueRow.total : 0,
                    visitsToday,
                    newUsersMonth
                },
                recentOrders,
                recentUsers,
                recentTickets,
                topProducts,
                revenueSeries,
                trafficSeries,
                maxRevenue,
                maxTraffic
            });
        } catch (err) { next(err); }
    });

    // =========================================================
    //  ANALYTICS
    // =========================================================
    function analyticsRange(query) {
        const from = query.dateFrom && moment(query.dateFrom, 'YYYY-MM-DD', true).isValid()
            ? query.dateFrom : moment().subtract(13, 'days').format('YYYY-MM-DD');
        const to = query.dateTo && moment(query.dateTo, 'YYYY-MM-DD', true).isValid()
            ? query.dateTo : moment().format('YYYY-MM-DD');
        return { from: from <= to ? from : to, to: from <= to ? to : from };
    }

    async function buildAnalytics(from, to) {
        const between = 'WHERE is_bot = 0 AND date(timestamp) BETWEEN ? AND ?';
        const totalVisits = await helpers.countRows('visits', between, [from, to]);
        const uniqueRow = await dbGet(`SELECT COUNT(DISTINCT ip) AS c FROM visits ${between}`, [from, to]);
        const topPages = await dbAll(
            `SELECT page, COUNT(*) AS count FROM visits ${between} GROUP BY page ORDER BY count DESC LIMIT 8`, [from, to]);
        const countries = await dbAll(
            `SELECT country, COUNT(*) AS count FROM visits ${between} GROUP BY country ORDER BY count DESC LIMIT 8`, [from, to]);
        const browsers = await dbAll(
            `SELECT CASE
                WHEN user_agent LIKE '%Edg%' THEN 'Edge'
                WHEN user_agent LIKE '%Chrome%' THEN 'Chrome'
                WHEN user_agent LIKE '%Firefox%' THEN 'Firefox'
                WHEN user_agent LIKE '%Safari%' THEN 'Safari'
                ELSE 'Other' END AS browser, COUNT(*) AS count
             FROM visits ${between} GROUP BY browser ORDER BY count DESC`, [from, to]);
        const peakHours = await dbAll(
            `SELECT strftime('%H', timestamp) AS hour, COUNT(*) AS count FROM visits ${between}
             GROUP BY strftime('%H', timestamp) ORDER BY hour`, [from, to]);
        const traffic = await dbAll(
            `SELECT date(timestamp) AS day, COUNT(*) AS visits, COUNT(DISTINCT ip) AS uniqueVisits
             FROM visits ${between} GROUP BY date(timestamp) ORDER BY day`, [from, to]);
        const recentVisits = await dbAll(
            'SELECT * FROM visits WHERE is_bot = 0 ORDER BY timestamp DESC LIMIT 12');
        const botVisits = await helpers.countRows('visits', 'WHERE is_bot = 1 AND date(timestamp) BETWEEN ? AND ?', [from, to]);

        // fill missing days so the chart has a continuous series
        const filled = [];
        const cursor = moment(from, 'YYYY-MM-DD');
        const end = moment(to, 'YYYY-MM-DD');
        const map = {};
        traffic.forEach((t) => { map[t.day] = t; });
        while (cursor.isSameOrBefore(end, 'day') && filled.length < 120) {
            const key = cursor.format('YYYY-MM-DD');
            filled.push({ day: key, label: cursor.format('DD MMM'), visits: map[key] ? map[key].visits : 0, uniqueVisits: map[key] ? map[key].uniqueVisits : 0 });
            cursor.add(1, 'day');
        }
        return { from, to, totalVisits, uniqueVisitors: uniqueRow ? uniqueRow.c : 0, topPages, countries, browsers, peakHours, traffic: filled, recentVisits, botVisits };
    }

    app.get('/admin/analytics', requireAdmin, async (req, res, next) => {
        try {
            const { from, to } = analyticsRange(req.query);
            const data = await buildAnalytics(from, to);
            const today = moment().format('YYYY-MM-DD');
            const yesterday = moment().subtract(1, 'day').format('YYYY-MM-DD');
            const visitsToday = await helpers.countRows('visits', 'WHERE is_bot = 0 AND date(timestamp) = ?', [today]);
            const visitsYesterday = await helpers.countRows('visits', 'WHERE is_bot = 0 AND date(timestamp) = ?', [yesterday]);
            const bounceRow = await dbGet(
                `SELECT COUNT(*) AS c FROM visits WHERE is_bot = 0 AND date(timestamp) BETWEEN ? AND ? AND page = '/view'`, [from, to]);
            const maxVisits = Math.max(1, ...data.traffic.map((t) => t.visits));
            const maxPage = Math.max(1, ...data.topPages.map((p) => p.count));
            const countryMax = Math.max(1, ...data.countries.map((c) => c.count));
            const browserMax = Math.max(1, ...data.browsers.map((b) => b.count));
            const hourMax = Math.max(1, ...data.peakHours.map((h) => h.count));
            res.render('admin/analytics', {
                title: 'Analytics',
                activePage: 'analytics',
                data,
                visitsToday,
                visitsYesterday,
                landingViews: bounceRow ? bounceRow.c : 0,
                maxVisits,
                maxPage,
                countryMax,
                browserMax,
                hourMax,
                range: { from, to }
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/analytics/data', requireAdmin, async (req, res) => {
        try {
            const { from, to } = analyticsRange(req.query);
            const data = await buildAnalytics(from, to);
            res.json({ ok: true, data });
        } catch (err) {
            res.status(500).json({ ok: false, error: 'Failed to load analytics.' });
        }
    });

    app.get('/admin/analytics/export', requireAdmin, async (req, res, next) => {
        try {
            const { from, to } = analyticsRange(req.query);
            const data = await buildAnalytics(from, to);
            const rows = [['Date', 'Visits', 'Unique visitors']].concat(
                data.traffic.map((t) => [t.day, t.visits, t.uniqueVisits])
            );
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename=unix-analytics-${from}-to-${to}.csv`);
            res.send(rows.map((r) => r.join(',')).join('\n'));
        } catch (err) { next(err); }
    });

    // =========================================================
    //  ORDERS
    // =========================================================
    app.get('/admin/orders', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const status = ['all', 'pending', 'active', 'suspended', 'completed', 'cancelled'].includes(req.query.status) ? req.query.status : 'all';
            const search = helpers.sanitize(req.query.search || '');
            let where = 'WHERE 1 = 1';
            const params = [];
            if (status !== 'all') { where += ' AND o.status = ?'; params.push(status); }
            if (search) { where += ' AND (o.productName LIKE ? OR o.id LIKE ? OR u.email LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM orders o LEFT JOIN users u ON o.userId = u.id ${where}`, params);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const orders = await dbAll(
                `SELECT o.*, u.email AS userEmail, u.firstName, u.lastName
                 FROM orders o LEFT JOIN users u ON o.userId = u.id
                 ${where} ORDER BY o.createdAt DESC LIMIT ? OFFSET ?`,
                [...params, perPage, (pagination.page - 1) * perPage]
            );
            const totals = await dbAll('SELECT status, COUNT(*) AS c FROM orders GROUP BY status');
            const statusCounts = { all: 0 };
            totals.forEach((t) => { statusCounts[t.status] = t.c; statusCounts.all += t.c; });
            res.render('admin/orders', {
                title: 'Orders',
                activePage: 'orders',
                orders,
                pagination,
                status,
                search,
                statusCounts
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/orders/:id', requireAdmin, async (req, res, next) => {
        try {
            const order = await dbGet('SELECT * FROM orders WHERE id = ?', [req.params.id]);
            if (!order) {
                req.flash('error', 'Order not found.');
                return res.redirect('/admin/orders');
            }
            const buyer = await dbGet('SELECT * FROM users WHERE id = ?', [order.userId]);
            const product = await getAdminProduct(order.productId);
            res.render('admin/order-detail', {
                title: `Order ${order.id.slice(0, 8).toUpperCase()}`,
                activePage: 'orders',
                order,
                buyer,
                product
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/orders/:id/status', requireAdmin, async (req, res, next) => {
        try {
            const allowed = ['pending', 'active', 'suspended', 'completed', 'cancelled'];
            if (!allowed.includes(req.body.status)) {
                req.flash('error', 'Invalid order status.');
                return res.redirect(`/admin/orders/${req.params.id}`);
            }
            await runDb('UPDATE orders SET status = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [req.body.status, req.params.id]);
            req.flash('success', `Order marked ${req.body.status}.`);
            res.redirect(`/admin/orders/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/orders/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            const order = await dbGet('SELECT status FROM orders WHERE id = ?', [req.params.id]);
            if (!order) {
                req.flash('error', 'Order not found.');
                return res.redirect('/admin/orders');
            }
            if (order.status === 'active') {
                req.flash('error', 'Active orders cannot be deleted. Suspend or cancel it first.');
                return res.redirect(`/admin/orders/${req.params.id}`);
            }
            await runDb('DELETE FROM orders WHERE id = ?', [req.params.id]);
            req.flash('success', 'Order deleted.');
            res.redirect('/admin/orders');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  PRODUCTS
    // =========================================================
    app.get('/admin/products', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const category = helpers.sanitize(req.query.category || '');
            const search = helpers.sanitize(req.query.search || '');
            let where = 'WHERE 1 = 1';
            const params = [];
            if (search) { where += ' AND (p.name LIKE ? OR p.description LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }
            if (category) {
                const catId = await getCategoryBySlug(category);
                if (catId) { where += ' AND p.categoryId = ?'; params.push(catId); }
            }
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM products p ${where}`, params);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const rows = await dbAll(
                `SELECT p.*, c.name AS categoryName, c.slug AS categorySlug, c.icon AS categoryIcon, c.accent AS categoryAccent,
                        (SELECT COUNT(*) FROM orders o WHERE o.productId = p.id) AS orderCount
                 FROM products p LEFT JOIN categories c ON p.categoryId = c.id
                 ${where} ORDER BY p.createdAt DESC LIMIT ? OFFSET ?`,
                [...params, perPage, (pagination.page - 1) * perPage]
            );
            const products = await processProducts(rows);
            const categories = await helpers.getCategories();
            res.render('admin/products', {
                title: 'Products',
                activePage: 'products',
                products,
                categories,
                pagination,
                filters: { category, search }
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/products/new', requireAdmin, async (req, res, next) => {
        try {
            const categories = await helpers.getCategories();
            res.render('admin/product-new', {
                title: 'New product',
                activePage: 'products',
                categories,
                product: {},
                isEdit: false
            });
        } catch (err) { next(err); }
    });

    function readProductForm(body) {
        const specs = {
            cpu: helpers.sanitize(body.cpu || ''),
            ram: body.ram ? helpers.sanitize(body.ram) + ' GB' : '',
            disk: body.disk ? helpers.sanitize(body.disk) + ' GB' : '',
            bandwidth: body.bandwidth ? helpers.sanitize(body.bandwidth) + ' GB' : 'Unlimited',
            locations: body.locations ? helpers.sanitize(body.locations) : 'Global'
        };
        const features = (body.features || '')
            .split(',')
            .map((f) => helpers.sanitize(f.trim()))
            .filter(Boolean);
        return {
            name: helpers.sanitize((body.name || '').trim()),
            description: helpers.sanitize((body.description || '').trim()),
            category: helpers.sanitize(body.category || ''),
            specs,
            features,
            priceMonthly: parseInt(body.priceMonthly, 10) || 0,
            priceQuarterly: parseInt(body.priceQuarterly, 10) || 0,
            priceYearly: parseInt(body.priceYearly, 10) || 0,
            isActive: body.isActive === 'on' ? 1 : 0
        };
    }

    app.post('/admin/products', requireAdmin, upload.single('image'), async (req, res, next) => {
        try {
            const data = readProductForm(req.body);
            const categoryId = await getCategoryBySlug(data.category);
            const errors = [];
            if (!data.name || !data.description || !categoryId) errors.push('Name, description and a valid category are required.');
            if (data.priceMonthly < 0 || data.priceQuarterly < 0 || data.priceYearly < 0) errors.push('Prices cannot be negative.');
            if (errors.length) {
                errors.forEach((e) => req.flash('error', e));
                const categories = await helpers.getCategories();
                return res.render('admin/product-new', { title: 'New product', activePage: 'products', categories, product: req.body, isEdit: false });
            }
            const image = req.file ? `/uploads/${req.file.filename}` : '';
            await runDb(
                `INSERT INTO products (id, name, description, categoryId, specs, features, priceMonthly, priceQuarterly, priceYearly, image, isActive)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [uuidv4(), data.name, data.description, categoryId, JSON.stringify(data.specs), JSON.stringify(data.features),
                 data.priceMonthly, data.priceQuarterly, data.priceYearly, image, data.isActive]
            );
            req.flash('success', `Product "${data.name}" created.`);
            res.redirect('/admin/products');
        } catch (err) { next(err); }
    });

    app.get('/admin/products/:id/edit', requireAdmin, async (req, res, next) => {
        try {
            const product = await getAdminProduct(req.params.id);
            if (!product) {
                req.flash('error', 'Product not found.');
                return res.redirect('/admin/products');
            }
            const categories = await helpers.getCategories();
            res.render('admin/product-edit', {
                title: 'Edit product',
                activePage: 'products',
                product,
                categories,
                isEdit: true
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/products/:id', requireAdmin, upload.single('image'), async (req, res, next) => {
        try {
            const data = readProductForm(req.body);
            const categoryId = await getCategoryBySlug(data.category);
            const errors = [];
            if (!data.name || !data.description || !categoryId) errors.push('Name, description and a valid category are required.');
            if (errors.length) {
                errors.forEach((e) => req.flash('error', e));
                const categories = await helpers.getCategories();
                return res.render('admin/product-edit', {
                    title: 'Edit product', activePage: 'products', categories,
                    product: Object.assign({}, req.body, { id: req.params.id, specs: data.specs, features: data.features, image: '' }),
                    isEdit: true
                });
            }
            const existing = await dbGet('SELECT image FROM products WHERE id = ?', [req.params.id]);
            if (!existing) {
                req.flash('error', 'Product not found.');
                return res.redirect('/admin/products');
            }
            let image = existing.image || '';
            if (req.body.removeImage === 'on') image = '';
            if (req.file) image = `/uploads/${req.file.filename}`;
            await runDb(
                `UPDATE products SET name = ?, description = ?, categoryId = ?, specs = ?, features = ?,
                 priceMonthly = ?, priceQuarterly = ?, priceYearly = ?, image = ?, isActive = ?, updatedAt = CURRENT_TIMESTAMP
                 WHERE id = ?`,
                [data.name, data.description, categoryId, JSON.stringify(data.specs), JSON.stringify(data.features),
                 data.priceMonthly, data.priceQuarterly, data.priceYearly, image, data.isActive, req.params.id]
            );
            req.flash('success', 'Product updated.');
            res.redirect('/admin/products');
        } catch (err) { next(err); }
    });

    app.post('/admin/products/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            const orderCount = await helpers.countRows('orders', "WHERE productId = ? AND status != 'cancelled'", [req.params.id]);
            if (orderCount > 0) {
                req.flash('error', 'This product has orders attached — deactivate it instead of deleting.');
                return res.redirect('/admin/products');
            }
            await runDb('DELETE FROM products WHERE id = ?', [req.params.id]);
            req.flash('success', 'Product deleted.');
            res.redirect('/admin/products');
        } catch (err) { next(err); }
    });

    app.get('/admin/products/:id/notes', requireAdmin, async (req, res, next) => {
        try {
            const product = await getAdminProduct(req.params.id);
            if (!product) {
                req.flash('error', 'Product not found.');
                return res.redirect('/admin/products');
            }
            const notes = await dbAll('SELECT * FROM product_notes WHERE productId = ? ORDER BY createdAt DESC', [req.params.id]);
            res.render('admin/product-notes', {
                title: `Notes · ${product.name}`,
                activePage: 'products',
                product,
                notes
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/products/:id/notes', requireAdmin, async (req, res, next) => {
        try {
            const note = helpers.sanitize(req.body.note || '');
            if (!note) {
                req.flash('error', 'Write a note before saving.');
                return res.redirect(`/admin/products/${req.params.id}/notes`);
            }
            await runDb('INSERT INTO product_notes (id, productId, note, isActive) VALUES (?, ?, ?, 1)',
                [uuidv4(), req.params.id, note]);
            req.flash('success', 'Note added.');
            res.redirect(`/admin/products/${req.params.id}/notes`);
        } catch (err) { next(err); }
    });

    app.post('/admin/notes/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            const note = await dbGet('SELECT * FROM product_notes WHERE id = ?', [req.params.id]);
            if (!note) {
                req.flash('error', 'Note not found.');
                return res.redirect('/admin/products');
            }
            await runDb('DELETE FROM product_notes WHERE id = ?', [req.params.id]);
            req.flash('success', 'Note deleted.');
            res.redirect(`/admin/products/${note.productId}/notes`);
        } catch (err) { next(err); }
    });

    // =========================================================
    //  CATEGORIES
    // =========================================================
    app.get('/admin/categories', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const count = await helpers.countRows('categories');
            const pagination = helpers.paginate(count, page, perPage);
            const categories = await dbAll(
                `SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.categoryId = c.id) AS productCount
                 FROM categories c ORDER BY c.sortOrder, c.name LIMIT ? OFFSET ?`,
                [perPage, (pagination.page - 1) * perPage]
            );
            res.render('admin/categories', {
                title: 'Categories',
                activePage: 'categories',
                categories,
                pagination
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/categories/new', requireAdmin, (req, res) => {
        res.render('admin/category-new', {
            title: 'New category',
            activePage: 'categories',
            category: {},
            isEdit: false,
            actionUrl: '/admin/categories'
        });
    });

    app.post('/admin/categories', requireAdmin, categoryUpload.single('image'), async (req, res, next) => {
        try {
            const name = helpers.sanitize((req.body.name || '').trim());
            if (name.length < 2) {
                req.flash('error', 'Category name must be at least 2 characters.');
                return res.redirect('/admin/categories/new');
            }
            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
            const existing = await dbGet('SELECT id FROM categories WHERE slug = ?', [slug]);
            if (existing) {
                req.flash('error', 'A category with that name already exists.');
                return res.redirect('/admin/categories/new');
            }
            await runDb(
                `INSERT INTO categories (id, name, slug, description, image, icon, accent, sortOrder, isActive)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [uuidv4(), name, slug, helpers.sanitize(req.body.description || ''),
                 req.file ? `/uploads/${req.file.filename}` : '',
                 helpers.sanitize(req.body.icon || 'server'),
                 helpers.sanitize(req.body.accent || '#8b5cf6'),
                 parseInt(req.body.sortOrder, 10) || 0,
                 req.body.isActive === 'on' ? 1 : 0]
            );
            req.flash('success', `Category "${name}" created.`);
            res.redirect('/admin/categories');
        } catch (err) { next(err); }
    });

    app.get('/admin/categories/:id/edit', requireAdmin, async (req, res, next) => {
        try {
            const category = await dbGet('SELECT * FROM categories WHERE id = ?', [req.params.id]);
            if (!category) {
                req.flash('error', 'Category not found.');
                return res.redirect('/admin/categories');
            }
            res.render('admin/category-edit', {
                title: 'Edit category',
                activePage: 'categories',
                category,
                isEdit: true,
                actionUrl: `/admin/categories/${category.id}`
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/categories/:id', requireAdmin, categoryUpload.single('image'), async (req, res, next) => {
        try {
            const category = await dbGet('SELECT * FROM categories WHERE id = ?', [req.params.id]);
            if (!category) {
                req.flash('error', 'Category not found.');
                return res.redirect('/admin/categories');
            }
            const name = helpers.sanitize((req.body.name || '').trim());
            if (name.length < 2) {
                req.flash('error', 'Category name must be at least 2 characters.');
                return res.redirect(`/admin/categories/${req.params.id}/edit`);
            }
            const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
            const clash = await dbGet('SELECT id FROM categories WHERE slug = ? AND id != ?', [slug, req.params.id]);
            if (clash) {
                req.flash('error', 'Another category already uses that slug.');
                return res.redirect(`/admin/categories/${req.params.id}/edit`);
            }
            let image = category.image || '';
            if (req.body.removeImage === 'on') image = '';
            if (req.file) image = `/uploads/${req.file.filename}`;
            await runDb(
                `UPDATE categories SET name = ?, slug = ?, description = ?, image = ?, icon = ?, accent = ?,
                 sortOrder = ?, isActive = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
                [name, slug, helpers.sanitize(req.body.description || ''), image,
                 helpers.sanitize(req.body.icon || 'server'), helpers.sanitize(req.body.accent || '#8b5cf6'),
                 parseInt(req.body.sortOrder, 10) || 0, req.body.isActive === 'on' ? 1 : 0, req.params.id]
            );
            req.flash('success', 'Category updated.');
            res.redirect('/admin/categories');
        } catch (err) { next(err); }
    });

    app.post('/admin/categories/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            const productCount = await helpers.countRows('products', 'WHERE categoryId = ?', [req.params.id]);
            if (productCount > 0) {
                req.flash('error', 'Move or delete the products in this category first.');
                return res.redirect('/admin/categories');
            }
            await runDb('DELETE FROM categories WHERE id = ?', [req.params.id]);
            req.flash('success', 'Category deleted.');
            res.redirect('/admin/categories');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  USERS
    // =========================================================
    app.get('/admin/users', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const status = ['all', 'active', 'inactive', 'admin'].includes(req.query.status) ? req.query.status : 'all';
            const search = helpers.sanitize(req.query.search || '');
            let where = 'WHERE 1 = 1';
            const params = [];
            if (status === 'active') where += ' AND isActive = 1';
            if (status === 'inactive') where += ' AND isActive = 0';
            if (status === 'admin') where += ' AND isAdmin = 1';
            if (search) {
                where += ' AND (email LIKE ? OR firstName LIKE ? OR lastName LIKE ?)';
                params.push(`%${search}%`, `%${search}%`, `%${search}%`);
            }
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM users ${where}`, params);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const users = await dbAll(
                `SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.userId = u.id) AS orderCount,
                        (SELECT COUNT(*) FROM tickets t WHERE t.userId = u.id) AS ticketCount
                 FROM users u ${where} ORDER BY u.createdAt DESC LIMIT ? OFFSET ?`,
                [...params, perPage, (pagination.page - 1) * perPage]
            );
            res.render('admin/users', {
                title: 'Users',
                activePage: 'users',
                users,
                pagination,
                status,
                search
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/users/new', requireAdmin, (req, res) => {
        res.render('admin/user-new', {
            title: 'New user',
            activePage: 'users',
            newUser: {}
        });
    });

    app.post('/admin/users', requireAdmin, async (req, res, next) => {
        try {
            const { email, firstName, lastName, phone } = req.body;
            if (!email || !firstName || !lastName) {
                req.flash('error', 'Email, first name and last name are required.');
                return res.redirect('/admin/users/new');
            }
            const existing = await dbGet('SELECT id FROM users WHERE email = ?', [String(email).toLowerCase().trim()]);
            if (existing) {
                req.flash('error', 'That email is already registered.');
                return res.redirect('/admin/users/new');
            }
            const tempPassword = Math.random().toString(36).slice(-8);
            await runDb(
                `INSERT INTO users (id, email, password, firstName, lastName, phone, coins, isAdmin, isActive)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [uuidv4(), String(email).toLowerCase().trim(), bcrypt.hashSync(tempPassword, 10),
                 helpers.sanitize(firstName), helpers.sanitize(lastName), helpers.sanitize(phone || ''),
                 parseInt(req.body.coins, 10) || 0,
                 req.body.isAdmin === 'on' ? 1 : 0, req.body.isActive === 'on' ? 1 : 0]
            );
            req.flash('success', `User created. Temporary password: ${tempPassword}`);
            res.redirect('/admin/users');
        } catch (err) { next(err); }
    });

    app.get('/admin/users/:id', requireAdmin, async (req, res, next) => {
        try {
            const userRow = await dbGet('SELECT * FROM users WHERE id = ?', [req.params.id]);
            if (!userRow) {
                req.flash('error', 'User not found.');
                return res.redirect('/admin/users');
            }
            const [orders, transactions, tickets, spentRow, openTickets] = await Promise.all([
                dbAll('SELECT * FROM orders WHERE userId = ? ORDER BY createdAt DESC LIMIT 8', [req.params.id]),
                dbAll('SELECT * FROM coin_transactions WHERE userId = ? ORDER BY createdAt DESC LIMIT 8', [req.params.id]),
                dbAll('SELECT * FROM tickets WHERE userId = ? ORDER BY updatedAt DESC LIMIT 6', [req.params.id]),
                dbGet("SELECT SUM(price) AS total FROM orders WHERE userId = ? AND status IN ('active','completed')", [req.params.id]),
                helpers.countRows('tickets', "WHERE userId = ? AND status IN ('open','in_progress','on_hold')", [req.params.id])
            ]);
            res.render('admin/user-detail', {
                title: `${userRow.firstName} ${userRow.lastName}`,
                activePage: 'users',
                profileUser: userRow,
                orders,
                transactions,
                tickets,
                spent: spentRow && spentRow.total ? spentRow.total : 0,
                openTickets
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/users/:id', requireAdmin, async (req, res, next) => {
        try {
            const target = await dbGet('SELECT * FROM users WHERE id = ?', [req.params.id]);
            if (!target) {
                req.flash('error', 'User not found.');
                return res.redirect('/admin/users');
            }
            const { email, firstName, lastName, phone, address, city, state, postalCode } = req.body;
            if (!email || !firstName || !lastName) {
                req.flash('error', 'Email and names are required.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            const clash = await dbGet('SELECT id FROM users WHERE email = ? AND id != ?', [String(email).toLowerCase().trim(), req.params.id]);
            if (clash) {
                req.flash('error', 'Another account already uses that email.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            let isAdmin = target.isAdmin;
            if (req.params.id !== req.session.user.id) {
                isAdmin = req.body.isAdmin === 'on' ? 1 : 0;
            }
            const isActive = req.body.isActive === 'on' ? 1 : 0;
            await runDb(
                `UPDATE users SET email = ?, firstName = ?, lastName = ?, phone = ?, address = ?, city = ?, state = ?,
                 postalCode = ?, isAdmin = ?, isActive = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
                [String(email).toLowerCase().trim(), helpers.sanitize(firstName), helpers.sanitize(lastName),
                 helpers.sanitize(phone || ''), helpers.sanitize(address || ''), helpers.sanitize(city || ''),
                 helpers.sanitize(state || ''), helpers.sanitize(postalCode || ''), isAdmin, isActive, req.params.id]
            );
            req.flash('success', 'User updated.');
            res.redirect(`/admin/users/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/users/:id/reset-password', requireAdmin, async (req, res, next) => {
        try {
            if (req.params.id === req.session.user.id) {
                req.flash('error', 'Use your profile page to change your own password.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            const target = await dbGet('SELECT id FROM users WHERE id = ?', [req.params.id]);
            if (!target) {
                req.flash('error', 'User not found.');
                return res.redirect('/admin/users');
            }
            const tempPassword = Math.random().toString(36).slice(-8);
            await runDb('UPDATE users SET password = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
                [bcrypt.hashSync(tempPassword, 10), req.params.id]);
            req.flash('success', `Password reset. Temporary password: ${tempPassword}`);
            res.redirect(`/admin/users/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/users/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            if (req.params.id === req.session.user.id) {
                req.flash('error', 'You cannot delete your own account.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            const orderCount = await helpers.countRows('orders', "WHERE userId = ? AND status != 'cancelled'", [req.params.id]);
            if (orderCount > 0) {
                req.flash('error', 'This user has active orders — cancel or suspend them first.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            await runDb('DELETE FROM users WHERE id = ?', [req.params.id]);
            req.flash('success', 'User deleted.');
            res.redirect('/admin/users');
        } catch (err) { next(err); }
    });

    async function adjustCoins(req, res, direction) {
        try {
            const amount = Math.abs(parseInt(req.body.coins, 10) || 0);
            if (!amount) {
                req.flash('error', 'Enter a coin amount greater than zero.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            const target = await dbGet('SELECT coins, email FROM users WHERE id = ?', [req.params.id]);
            if (!target) {
                req.flash('error', 'User not found.');
                return res.redirect('/admin/users');
            }
            if (direction < 0 && target.coins < amount) {
                req.flash('error', 'User does not have that many coins.');
                return res.redirect(`/admin/users/${req.params.id}`);
            }
            await runDb('UPDATE users SET coins = coins + ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
                [direction * amount, req.params.id]);
            await runDb(
                `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, notes, adminVerified, verifiedAt)
                 VALUES (?, ?, NULL, ?, ?, ?, 'completed', ?, 1, ?)`,
                [uuidv4(), req.params.id, `ADM-${Date.now().toString(36).toUpperCase()}`, 0,
                 direction * amount, `Admin ${direction > 0 ? 'credit' : 'debit'}: ${helpers.sanitize(req.body.reason || 'manual adjustment')}`,
                 moment().format('YYYY-MM-DD HH:mm:ss')]
            );
            req.flash('success', `${amount} coins ${direction > 0 ? 'added to' : 'deducted from'} ${target.email}.`);
            res.redirect(`/admin/users/${req.params.id}`);
        } catch (err) { next(err); }
    }
    app.post('/admin/users/:id/add-coins', requireAdmin, (req, res, next) => adjustCoins(req, res, 1));
    app.post('/admin/users/:id/deduct-coins', requireAdmin, (req, res, next) => adjustCoins(req, res, -1));

    // =========================================================
    //  COIN TRANSACTIONS / PACKAGES
    // =========================================================
    app.get('/admin/coin-transactions', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const status = ['all', 'pending', 'completed', 'rejected'].includes(req.query.status) ? req.query.status : 'all';
            let where = 'WHERE 1 = 1';
            const params = [];
            if (status !== 'all') { where += ' AND ct.status = ?'; params.push(status); }
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM coin_transactions ct ${where}`, params);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const transactions = await dbAll(
                `SELECT ct.*, u.email AS userEmail, u.firstName, u.lastName, cp.name AS packageName
                 FROM coin_transactions ct
                 LEFT JOIN users u ON ct.userId = u.id
                 LEFT JOIN coin_packages cp ON ct.packageId = cp.id
                 ${where} ORDER BY ct.createdAt DESC LIMIT ? OFFSET ?`,
                [...params, perPage, (pagination.page - 1) * perPage]
            );
            const totals = await dbAll('SELECT status, COUNT(*) AS c FROM coin_transactions GROUP BY status');
            const statusCounts = { all: 0 };
            totals.forEach((t) => { statusCounts[t.status] = t.c; statusCounts.all += t.c; });
            res.render('admin/coin-transactions', {
                title: 'Coin transactions',
                activePage: 'coin-transactions',
                transactions,
                pagination,
                status,
                statusCounts
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/coin-transactions/:id/verify', requireAdmin, async (req, res, next) => {
        try {
            const tx = await dbGet('SELECT * FROM coin_transactions WHERE id = ?', [req.params.id]);
            if (!tx) {
                req.flash('error', 'Transaction not found.');
                return res.redirect('/admin/coin-transactions');
            }
            if (tx.status !== 'pending') {
                req.flash('error', 'That transaction has already been processed.');
                return res.redirect('/admin/coin-transactions');
            }
            await runDb('UPDATE users SET coins = coins + ? WHERE id = ?', [tx.coins, tx.userId]);
            await runDb(
                `UPDATE coin_transactions SET status = 'completed', adminVerified = 1, verifiedAt = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
                [moment().format('YYYY-MM-DD HH:mm:ss'), tx.id]
            );
            req.flash('success', `Verified — ${tx.coins} coins credited.`);
            res.redirect('/admin/coin-transactions');
        } catch (err) { next(err); }
    });

    app.post('/admin/coin-transactions/:id/reject', requireAdmin, async (req, res, next) => {
        try {
            const tx = await dbGet('SELECT * FROM coin_transactions WHERE id = ?', [req.params.id]);
            if (!tx || tx.status !== 'pending') {
                req.flash('error', 'That transaction cannot be rejected.');
                return res.redirect('/admin/coin-transactions');
            }
            const reason = helpers.sanitize(req.body.reason || '');
            await runDb(
                `UPDATE coin_transactions SET status = 'rejected', adminVerified = 0, notes = ?, verifiedAt = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
                [reason ? `Rejected: ${reason}` : tx.notes || '', moment().format('YYYY-MM-DD HH:mm:ss'), tx.id]
            );
            req.flash('success', 'Transaction rejected.');
            res.redirect('/admin/coin-transactions');
        } catch (err) { next(err); }
    });

    app.get('/admin/coin-packages', requireAdmin, async (req, res, next) => {
        try {
            const packages = await dbAll(
                `SELECT cp.*, (SELECT COUNT(*) FROM coin_transactions ct WHERE ct.packageId = cp.id AND ct.status = 'completed') AS sold
                 FROM coin_packages cp ORDER BY cp.coins`
            );
            res.render('admin/coin-packages', {
                title: 'Coin packages',
                activePage: 'coin-packages',
                packages
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/coin-packages/new', requireAdmin, (req, res) => {
        res.render('admin/coin-package-new', {
            title: 'New coin package',
            activePage: 'coin-packages',
            pkg: {},
            isEdit: false
        });
    });

    app.post('/admin/coin-packages', requireAdmin, async (req, res, next) => {
        try {
            const { name, description, coins, price } = req.body;
            const coinValue = parseInt(coins, 10);
            const priceValue = parseFloat(price);
            if (!name || !coinValue || coinValue <= 0 || !priceValue || priceValue <= 0) {
                req.flash('error', 'Name, a positive coin amount and a positive price are required.');
                return res.redirect('/admin/coin-packages/new');
            }
            await runDb('INSERT INTO coin_packages (id, name, description, coins, price, isActive) VALUES (?, ?, ?, ?, ?, ?)',
                [uuidv4(), helpers.sanitize(name), helpers.sanitize(description || ''), coinValue, priceValue,
                 req.body.isActive === 'on' ? 1 : 0]);
            req.flash('success', 'Coin package created.');
            res.redirect('/admin/coin-packages');
        } catch (err) { next(err); }
    });

    app.get('/admin/coin-packages/:id/edit', requireAdmin, async (req, res, next) => {
        try {
            const pkg = await dbGet('SELECT * FROM coin_packages WHERE id = ?', [req.params.id]);
            if (!pkg) {
                req.flash('error', 'Package not found.');
                return res.redirect('/admin/coin-packages');
            }
            res.render('admin/coin-package-edit', {
                title: 'Edit coin package',
                activePage: 'coin-packages',
                pkg,
                isEdit: true
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/coin-packages/:id', requireAdmin, async (req, res, next) => {
        try {
            const { name, description, coins, price } = req.body;
            const coinValue = parseInt(coins, 10);
            const priceValue = parseFloat(price);
            if (!name || !coinValue || coinValue <= 0 || !priceValue || priceValue <= 0) {
                req.flash('error', 'Name, a positive coin amount and a positive price are required.');
                return res.redirect(`/admin/coin-packages/${req.params.id}/edit`);
            }
            await runDb(
                'UPDATE coin_packages SET name = ?, description = ?, coins = ?, price = ?, isActive = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
                [helpers.sanitize(name), helpers.sanitize(description || ''), coinValue, priceValue,
                 req.body.isActive === 'on' ? 1 : 0, req.params.id]
            );
            req.flash('success', 'Coin package updated.');
            res.redirect('/admin/coin-packages');
        } catch (err) { next(err); }
    });

    app.post('/admin/coin-packages/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            await runDb('DELETE FROM coin_packages WHERE id = ?', [req.params.id]);
            req.flash('success', 'Coin package deleted.');
            res.redirect('/admin/coin-packages');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  COUPONS
    // =========================================================
    app.get('/admin/coupons', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const status = ['all', 'active', 'expired'].includes(req.query.status) ? req.query.status : 'all';
            let where = '';
            if (status === 'active') where = " WHERE isActive = 1 AND (expiresAt IS NULL OR expiresAt > datetime('now')) AND (maxUses IS NULL OR uses < maxUses)";
            if (status === 'expired') where = " WHERE isActive = 0 OR (expiresAt IS NOT NULL AND expiresAt <= datetime('now')) OR (maxUses IS NOT NULL AND uses >= maxUses)";
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM coupons ${where}`);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const coupons = await dbAll(`SELECT * FROM coupons ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`,
                [perPage, (pagination.page - 1) * perPage]);
            res.render('admin/coupons', {
                title: 'Coupons',
                activePage: 'coupons',
                coupons,
                pagination,
                status
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/coupons/new', requireAdmin, (req, res) => {
        res.render('admin/coupon-new', {
            title: 'New coupon',
            activePage: 'coupons',
            coupon: { couponType: 'percent', expiresAt: moment().add(30, 'days').format('YYYY-MM-DD') },
            isEdit: false
        });
    });

    app.post('/admin/coupons', requireAdmin, async (req, res, next) => {
        try {
            const code = helpers.sanitize((req.body.code || '').toUpperCase().trim());
            const type = req.body.couponType === 'fixed' ? 'fixed' : 'percent';
            const value = parseFloat(req.body.value);
            if (!code || code.length < 3 || !value || value <= 0) {
                req.flash('error', 'A code (3+ characters) and a positive value are required.');
                return res.redirect('/admin/coupons/new');
            }
            if (type === 'percent' && (value < 1 || value > 100)) {
                req.flash('error', 'Percentage discounts must be between 1 and 100.');
                return res.redirect('/admin/coupons/new');
            }
            const clash = await dbGet('SELECT id FROM coupons WHERE code = ?', [code]);
            if (clash) {
                req.flash('error', 'That coupon code already exists.');
                return res.redirect('/admin/coupons/new');
            }
            await runDb(
                'INSERT INTO coupons (id, code, couponType, value, maxUses, expiresAt, isActive) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [uuidv4(), code, type, value, req.body.maxUses ? parseInt(req.body.maxUses, 10) : null,
                 req.body.expiresAt || null, req.body.isActive === 'on' ? 1 : 0]
            );
            req.flash('success', `Coupon ${code} created.`);
            res.redirect('/admin/coupons');
        } catch (err) { next(err); }
    });

    app.get('/admin/coupons/:id/edit', requireAdmin, async (req, res, next) => {
        try {
            const coupon = await dbGet('SELECT * FROM coupons WHERE id = ?', [req.params.id]);
            if (!coupon) {
                req.flash('error', 'Coupon not found.');
                return res.redirect('/admin/coupons');
            }
            res.render('admin/coupon-edit', {
                title: 'Edit coupon',
                activePage: 'coupons',
                coupon,
                isEdit: true
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/coupons/:id', requireAdmin, async (req, res, next) => {
        try {
            const code = helpers.sanitize((req.body.code || '').toUpperCase().trim());
            const type = req.body.couponType === 'fixed' ? 'fixed' : 'percent';
            const value = parseFloat(req.body.value);
            if (!code || code.length < 3 || !value || value <= 0) {
                req.flash('error', 'A code (3+ characters) and a positive value are required.');
                return res.redirect(`/admin/coupons/${req.params.id}/edit`);
            }
            const clash = await dbGet('SELECT id FROM coupons WHERE code = ? AND id != ?', [code, req.params.id]);
            if (clash) {
                req.flash('error', 'Another coupon already uses that code.');
                return res.redirect(`/admin/coupons/${req.params.id}/edit`);
            }
            await runDb(
                `UPDATE coupons SET code = ?, couponType = ?, value = ?, maxUses = ?, expiresAt = ?, isActive = ?,
                 updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
                [code, type, value, req.body.maxUses ? parseInt(req.body.maxUses, 10) : null,
                 req.body.expiresAt || null, req.body.isActive === 'on' ? 1 : 0, req.params.id]
            );
            req.flash('success', 'Coupon updated.');
            res.redirect('/admin/coupons');
        } catch (err) { next(err); }
    });

    app.post('/admin/coupons/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            await runDb('DELETE FROM coupons WHERE id = ?', [req.params.id]);
            req.flash('success', 'Coupon deleted.');
            res.redirect('/admin/coupons');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  REVIEWS
    // =========================================================
    app.get('/admin/reviews', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const filter = ['all', 'pending', 'approved'].includes(req.query.filter) ? req.query.filter : 'all';
            let where = '';
            if (filter === 'pending') where = ' WHERE r.isApproved = 0';
            if (filter === 'approved') where = ' WHERE r.isApproved = 1';
            const countRow = await dbGet(`SELECT COUNT(*) AS c FROM reviews r ${where}`);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const reviews = await dbAll(
                `SELECT r.*, p.name AS productName, u.firstName, u.lastName, u.email
                 FROM reviews r
                 LEFT JOIN products p ON r.productId = p.id
                 LEFT JOIN users u ON r.userId = u.id
                 ${where} ORDER BY r.createdAt DESC LIMIT ? OFFSET ?`,
                [perPage, (pagination.page - 1) * perPage]
            );
            const avgRow = await dbGet('SELECT AVG(rating) AS avg FROM reviews WHERE isApproved = 1');
            res.render('admin/reviews', {
                title: 'Reviews',
                activePage: 'reviews',
                reviews,
                pagination,
                filter,
                averageRating: avgRow && avgRow.avg ? Number(avgRow.avg).toFixed(2) : '0.00'
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/reviews/:id/approve', requireAdmin, async (req, res, next) => {
        try {
            await runDb('UPDATE reviews SET isApproved = 1 WHERE id = ?', [req.params.id]);
            req.flash('success', 'Review approved and published.');
            res.redirect('/admin/reviews');
        } catch (err) { next(err); }
    });

    app.post('/admin/reviews/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            await runDb('DELETE FROM reviews WHERE id = ?', [req.params.id]);
            req.flash('success', 'Review deleted.');
            res.redirect('/admin/reviews');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  TICKETS
    // =========================================================
    app.get('/admin/tickets', requireAdmin, async (req, res, next) => {
        try {
            const page = safePage(req.query.page);
            const filters = {
                status: req.query.status || 'all',
                department: req.query.department || 'all',
                priority: req.query.priority || 'all',
                search: helpers.sanitize(req.query.search || '')
            };
            let where = 'WHERE 1 = 1';
            const params = [];
            if (filters.status !== 'all' && TICKET_CONFIG.STATUSES.includes(filters.status)) {
                where += ' AND t.status = ?'; params.push(filters.status);
            }
            if (filters.department !== 'all' && TICKET_CONFIG.DEPARTMENTS.includes(filters.department)) {
                where += ' AND t.department = ?'; params.push(filters.department);
            }
            if (filters.priority !== 'all' && TICKET_CONFIG.PRIORITIES.includes(filters.priority)) {
                where += ' AND t.priority = ?'; params.push(filters.priority);
            }
            if (filters.search) {
                where += ' AND (t.subject LIKE ? OR t.id LIKE ? OR u.email LIKE ?)';
                params.push(`%${filters.search}%`, `%${filters.search}%`, `%${filters.search}%`);
            }
            const countRow = await dbGet(
                `SELECT COUNT(*) AS c FROM tickets t LEFT JOIN users u ON t.userId = u.id ${where}`, params);
            const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
            const tickets = await dbAll(
                `SELECT t.*, u.email AS userEmail, u.firstName, u.lastName
                 FROM tickets t LEFT JOIN users u ON t.userId = u.id
                 ${where} ORDER BY t.updatedAt DESC LIMIT ? OFFSET ?`,
                [...params, perPage, (pagination.page - 1) * perPage]
            );
            const statusCounts = { all: await helpers.countRows('tickets') };
            for (const s of TICKET_CONFIG.STATUSES) {
                statusCounts[s] = await helpers.countRows('tickets', 'WHERE status = ?', [s]);
            }
            res.render('admin/tickets', {
                title: 'Support tickets',
                activePage: 'tickets',
                tickets,
                pagination,
                filters,
                statusCounts
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/tickets/stats', requireAdmin, async (req, res, next) => {
        try {
            const byStatus = await dbAll('SELECT status, COUNT(*) AS count FROM tickets GROUP BY status');
            const byDepartment = await dbAll('SELECT department, COUNT(*) AS count FROM tickets GROUP BY department ORDER BY count DESC');
            const byPriority = await dbAll('SELECT priority, COUNT(*) AS count FROM tickets GROUP BY priority ORDER BY count DESC');
            const total = await helpers.countRows('tickets');
            const resolved = await helpers.countRows('tickets', "WHERE status IN ('resolved','closed')");
            const avgRow = await dbGet(
                `SELECT AVG((julianday(COALESCE(slaDue, updatedAt)) - julianday(createdAt)) * 24) AS hours FROM tickets`);
            const maxDept = Math.max(1, ...byDepartment.map((d) => d.count));
            const maxPriority = Math.max(1, ...byPriority.map((d) => d.count));
            res.render('admin/ticket-stats', {
                title: 'Ticket analytics',
                activePage: 'tickets',
                byStatus,
                byDepartment,
                byPriority,
                total,
                resolved,
                resolveRate: total ? Math.round((resolved / total) * 100) : 0,
                avgSlaHours: avgRow && avgRow.hours ? Number(avgRow.hours).toFixed(1) : '0.0',
                maxDept,
                maxPriority
            });
        } catch (err) { next(err); }
    });

    app.get('/admin/tickets/:id', requireAdmin, async (req, res, next) => {
        try {
            const ticket = await dbGet('SELECT * FROM tickets WHERE id = ?', [req.params.id]);
            if (!ticket) {
                req.flash('error', 'Ticket not found.');
                return res.redirect('/admin/tickets');
            }
            await runDb('UPDATE tickets SET isReadAdmin = 1 WHERE id = ?', [ticket.id]);
            const [replies, notes, admins, customer] = await Promise.all([
                dbAll(
                    `SELECT tr.*, u.firstName, u.lastName, u.isAdmin FROM ticket_replies tr
                     LEFT JOIN users u ON tr.userId = u.id
                     WHERE tr.ticketId = ? AND tr.isNote = 0 ORDER BY tr.createdAt ASC`, [ticket.id]
                ),
                dbAll(
                    `SELECT tn.*, u.firstName, u.lastName FROM ticket_notes tn
                     LEFT JOIN users u ON tn.userId = u.id
                     WHERE tn.ticketId = ? ORDER BY tn.createdAt ASC`, [ticket.id]
                ),
                dbAll('SELECT id, email, firstName, lastName FROM users WHERE isAdmin = 1 ORDER BY firstName'),
                dbGet('SELECT id, email, firstName, lastName, coins FROM users WHERE id = ?', [ticket.userId])
            ]);
            replies.forEach((r) => {
                try { r.attachments = JSON.parse(r.attachments || '[]'); } catch (e) { r.attachments = []; }
            });
            res.render('admin/ticket-view', {
                title: ticket.subject,
                activePage: 'tickets',
                ticket,
                replies,
                notes,
                admins,
                customer,
                tags: ticket.tags ? ticket.tags.split(',') : [],
                sla: slaStatus(ticket),
                cannedResponses: [
                    { id: 'welcome', name: 'Welcome message', content: 'Thanks for reaching out! We are looking into this and will update you shortly.' },
                    { id: 'info', name: 'Need more info', content: 'To help us investigate, could you share the exact error message, the approximate time it happened, and any recent changes you made?' },
                    { id: 'resolved', name: 'Issue resolved', content: 'This should be sorted now — I have verified it on our side. Please reply if anything still looks off and we will reopen immediately.' }
                ]
            });
        } catch (err) { next(err); }
    });

    app.post('/admin/tickets/:id/reply', requireAdmin, async (req, res, next) => {
        try {
            const ticket = await dbGet('SELECT * FROM tickets WHERE id = ?', [req.params.id]);
            if (!ticket) {
                req.flash('error', 'Ticket not found.');
                return res.redirect('/admin/tickets');
            }
            let message = helpers.sanitize(req.body.message || '');
            if (req.body.canned) {
                const canned = {
                    welcome: 'Thanks for reaching out! We are looking into this and will update you shortly.',
                    info: 'To help us investigate, could you share the exact error message, the approximate time it happened, and any recent changes you made?',
                    resolved: 'This should be sorted now — I have verified it on our side. Please reply if anything still looks off and we will reopen immediately.'
                }[req.body.canned];
                if (canned) message = canned;
            }
            if (!message || message.length < 2) {
                req.flash('error', 'Write a reply or pick a canned response.');
                return res.redirect(`/admin/tickets/${ticket.id}`);
            }
            await runDb(
                `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments, isAdminReply, isNote)
                 VALUES (?, ?, ?, ?, '[]', 1, 0)`,
                [uuidv4(), ticket.id, req.session.user.id, message]
            );
            await runDb(
                `UPDATE tickets SET updatedAt = CURRENT_TIMESTAMP, isReadAdmin = 1, isReadUser = 0,
                 status = CASE WHEN status = 'open' THEN 'in_progress' ELSE status END WHERE id = ?`,
                [ticket.id]
            );
            req.flash('success', 'Reply sent to the customer.');
            res.redirect(`/admin/tickets/${ticket.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/tickets/:id/note', requireAdmin, async (req, res, next) => {
        try {
            const message = helpers.sanitize(req.body.message || '');
            if (!message) {
                req.flash('error', 'Internal note cannot be empty.');
                return res.redirect(`/admin/tickets/${req.params.id}`);
            }
            await runDb('INSERT INTO ticket_notes (id, ticketId, userId, message) VALUES (?, ?, ?, ?)',
                [uuidv4(), req.params.id, req.session.user.id, message]);
            req.flash('success', 'Internal note saved (customers cannot see it).');
            res.redirect(`/admin/tickets/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/tickets/:id/status', requireAdmin, async (req, res, next) => {
        try {
            if (!TICKET_CONFIG.STATUSES.includes(req.body.status)) {
                req.flash('error', 'Invalid ticket status.');
                return res.redirect(`/admin/tickets/${req.params.id}`);
            }
            await runDb('UPDATE tickets SET status = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
                [req.body.status, req.params.id]);
            req.flash('success', `Ticket marked ${req.body.status.replace('_', ' ')}.`);
            res.redirect(`/admin/tickets/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/tickets/:id/assign', requireAdmin, async (req, res, next) => {
        try {
            await runDb('UPDATE tickets SET assignedTo = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?',
                [req.body.assignTo || null, req.params.id]);
            req.flash('success', 'Ticket assignment updated.');
            res.redirect(`/admin/tickets/${req.params.id}`);
        } catch (err) { next(err); }
    });

    app.post('/admin/tickets/:id/delete', requireAdmin, async (req, res, next) => {
        try {
            await runDb('DELETE FROM ticket_replies WHERE ticketId = ?', [req.params.id]);
            await runDb('DELETE FROM ticket_notes WHERE ticketId = ?', [req.params.id]);
            await runDb('DELETE FROM tickets WHERE id = ?', [req.params.id]);
            req.flash('success', 'Ticket deleted.');
            res.redirect('/admin/tickets');
        } catch (err) { next(err); }
    });

    // =========================================================
    //  SETTINGS
    // =========================================================
    app.get('/admin/settings', requireAdmin, (req, res) => {
        res.render('admin/settings', {
            title: 'Settings',
            activePage: 'settings'
        });
    });

    app.post('/admin/settings/general', requireAdmin,
        upload.fields([{ name: 'site_logo', maxCount: 1 }, { name: 'site_favicon', maxCount: 1 }]),
        async (req, res, next) => {
            try {
                const fields = ['site_name', 'site_description', 'contact_email', 'currency_name', 'currency_icon', 'upi_id', 'coin_value'];
                for (const key of fields) {
                    if (typeof req.body[key] === 'string') {
                        await upsertSetting(key, helpers.sanitize(req.body[key]), key.replace(/_/g, ' '));
                    }
                }
                if (req.files && req.files.site_logo && req.files.site_logo[0]) {
                    await upsertSetting('site_logo', `/uploads/${req.files.site_logo[0].filename}`, 'Site logo');
                }
                if (req.body.remove_logo === 'on') await upsertSetting('site_logo', '', 'Site logo');
                if (req.files && req.files.site_favicon && req.files.site_favicon[0]) {
                    await upsertSetting('site_favicon', `/uploads/${req.files.site_favicon[0].filename}`, 'Site favicon');
                }
                req.flash('success', 'General settings saved.');
                res.redirect('/admin/settings');
            } catch (err) { next(err); }
        });

    app.post('/admin/settings/maintenance', requireAdmin, async (req, res, next) => {
        try {
            await upsertSetting('maintenance_mode', req.body.maintenance_mode === 'on' ? 'on' : 'off', 'Maintenance mode');
            await upsertSetting('maintenance_message', helpers.sanitize(req.body.maintenance_message || ''),
                'Message shown during maintenance');
            req.flash('success', req.body.maintenance_mode === 'on'
                ? 'Maintenance mode is ON — visitors now see the maintenance page.'
                : 'Maintenance mode is OFF — the site is public again.');
            res.redirect('/admin/settings');
        } catch (err) { next(err); }
    });
};
