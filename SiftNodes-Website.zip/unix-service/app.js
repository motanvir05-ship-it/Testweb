require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');
const bcrypt = require('bcryptjs');
const sqlite3 = require('sqlite3').verbose();
const session = require('express-session');
const flash = require('connect-flash');
const QRCode = require('qrcode');

// =========================================================
//  SIFTNODES — user area (no admin views)
//  Dark, modern hosting storefront.
// =========================================================

const DEMO_MODE = process.env.DEMO_MODE !== 'false';
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'hosting.db');
const UPLOAD_DIR = path.join(__dirname, 'public/uploads');

// ---------- upload folders ----------
['uploads', 'uploads/tickets', 'uploads/screenshots'].forEach((dir) => {
    const full = path.join(__dirname, 'public', dir);
    if (!fs.existsSync(full)) fs.mkdirSync(full, { recursive: true });
});

// =========================================================
//  DATABASE
// =========================================================
const db = new sqlite3.Database(DB_PATH);

function runDb(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve(this);
        });
    });
}
function dbGet(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });
}
function dbAll(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
    });
}

async function createSchema() {
    const tables = [
        `CREATE TABLE IF NOT EXISTS categories (
            id TEXT PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            description TEXT,
            image TEXT,
            icon TEXT DEFAULT 'server',
            accent TEXT DEFAULT '#7c5cff',
            sortOrder INTEGER DEFAULT 0,
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            firstName TEXT NOT NULL,
            lastName TEXT NOT NULL,
            phone TEXT,
            address TEXT,
            city TEXT,
            state TEXT,
            postalCode TEXT,
            coins INTEGER DEFAULT 0,
            isAdmin INTEGER DEFAULT 0,
            isActive INTEGER DEFAULT 1,
            loginAttempts INTEGER DEFAULT 0,
            lastLogin DATETIME,
            lastIp TEXT,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            categoryId TEXT NOT NULL,
            specs TEXT NOT NULL,
            features TEXT,
            priceMonthly INTEGER DEFAULT 0,
            priceQuarterly INTEGER DEFAULT 0,
            priceYearly INTEGER DEFAULT 0,
            image TEXT,
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS product_notes (
            id TEXT PRIMARY KEY,
            productId TEXT NOT NULL,
            note TEXT NOT NULL,
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS reviews (
            id TEXT PRIMARY KEY,
            productId TEXT NOT NULL,
            userId TEXT NOT NULL,
            rating INTEGER NOT NULL,
            comment TEXT,
            isApproved INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS likes (
            id TEXT PRIMARY KEY,
            productId TEXT NOT NULL,
            userId TEXT NOT NULL,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(productId, userId)
        )`,
        `CREATE TABLE IF NOT EXISTS orders (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            productId TEXT NOT NULL,
            productName TEXT NOT NULL,
            productCategory TEXT NOT NULL,
            billingCycle TEXT NOT NULL,
            originalPrice INTEGER NOT NULL,
            discount INTEGER DEFAULT 0,
            price INTEGER NOT NULL,
            note TEXT,
            paymentMethod TEXT NOT NULL DEFAULT 'coins',
            status TEXT DEFAULT 'pending',
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS coin_packages (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            coins INTEGER NOT NULL,
            price REAL NOT NULL,
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS coin_transactions (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            packageId TEXT,
            transactionId TEXT,
            amount REAL NOT NULL,
            coins INTEGER NOT NULL,
            status TEXT DEFAULT 'pending',
            upiId TEXT,
            screenshot TEXT,
            notes TEXT,
            adminVerified INTEGER DEFAULT 0,
            verifiedAt DATETIME,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS coupons (
            id TEXT PRIMARY KEY,
            code TEXT UNIQUE NOT NULL,
            couponType TEXT DEFAULT 'fixed',
            value REAL NOT NULL,
            maxUses INTEGER,
            uses INTEGER DEFAULT 0,
            expiresAt DATETIME,
            isActive INTEGER DEFAULT 1,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS tickets (
            id TEXT PRIMARY KEY,
            userId TEXT NOT NULL,
            subject TEXT NOT NULL,
            description TEXT,
            department TEXT NOT NULL,
            priority TEXT NOT NULL,
            status TEXT DEFAULT 'open',
            assignedTo TEXT,
            tags TEXT,
            isReadUser INTEGER DEFAULT 0,
            isReadAdmin INTEGER DEFAULT 0,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
            slaDue DATETIME
        )`,
        `CREATE TABLE IF NOT EXISTS ticket_replies (
            id TEXT PRIMARY KEY,
            ticketId TEXT NOT NULL,
            userId TEXT NOT NULL,
            message TEXT NOT NULL,
            attachments TEXT,
            isAdminReply INTEGER DEFAULT 0,
            isNote INTEGER DEFAULT 0,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS ticket_notes (
            id TEXT PRIMARY KEY,
            ticketId TEXT NOT NULL,
            userId TEXT NOT NULL,
            message TEXT NOT NULL,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        `CREATE TABLE IF NOT EXISTS visits (
            id TEXT PRIMARY KEY,
            ip TEXT NOT NULL,
            country TEXT,
            page TEXT NOT NULL,
            user_agent TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_bot INTEGER DEFAULT 0
        )`,
        `CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT
        )`
    ];
    for (const sql of tables) await runDb(sql);
}

// =========================================================
//  SEED DATA (demo content)
// =========================================================
const CATEGORY_SEED = [
    { name: 'Minecraft Hosting', slug: 'minecraft', icon: 'blocks', accent: '#8b5cf6', sort: 1,
      description: 'Lag-free Java & Bedrock servers with one-click modpack installs and instant setup.' },
    { name: 'VPS Hosting', slug: 'vps', icon: 'server', accent: '#22d3ee', sort: 2,
      description: 'Full root access on AMD Ryzen 9 nodes with NVMe storage and 10 Gbps uplinks.' },
    { name: 'Web Hosting', slug: 'web-hosting', icon: 'globe', accent: '#34d399', sort: 3,
      description: 'Blazing-fast shared hosting for WordPress, Laravel and modern JavaScript apps.' },
    { name: 'Dedicated Servers', slug: 'dedicated-servers', icon: 'cpu', accent: '#f59e0b', sort: 4,
      description: 'Bare-metal performance with zero noisy neighbours for your heaviest workloads.' }
];

const PRODUCT_SEED = [
    {
        name: 'Grass Plan', cat: 'minecraft', badge: 'Starter', accentIcon: 'blocks',
        description: 'A cozy, lag-free home for your first Minecraft world. Perfect for friends and small communities.',
        specs: { ram: '2 GB DDR4', cpu: '1 vCore', disk: '10 GB NVMe', slots: 'Unlimited slots', panel: 'Pterodactyl' },
        features: ['Instant setup in 60 seconds', 'One-click modpack installer', 'Free subdomain', 'DDoS protection', 'Daily off-site backups', '24/7 support'],
        monthly: 149, quarterly: 399, yearly: 1499
    },
    {
        name: 'Diamond Plan', cat: 'minecraft', badge: 'Popular', accentIcon: 'blocks',
        description: 'Our most-loved Minecraft plan. Smooth 20 TPS for busy servers with plugins and mods.',
        specs: { ram: '4 GB DDR4', cpu: '2 vCores', disk: '25 GB NVMe', slots: 'Unlimited slots', panel: 'Pterodactyl' },
        features: ['Instant setup in 60 seconds', 'One-click modpack installer', 'Free subdomain', 'DDoS protection', 'Daily off-site backups', 'MySQL database', 'Dedicated IP available'],
        monthly: 249, quarterly: 699, yearly: 2499
    },
    {
        name: 'Netherite Plan', cat: 'minecraft', badge: 'Power', accentIcon: 'blocks',
        description: 'For large networks and heavy modpacks. Ryzen 9 cores with priority CPU scheduling.',
        specs: { ram: '8 GB DDR4', cpu: '4 vCores', disk: '50 GB NVMe', slots: 'Unlimited slots', panel: 'Pterodactyl' },
        features: ['Instant setup in 60 seconds', 'One-click modpack installer', 'Free subdomain', 'Advanced DDoS protection', 'Hourly backups', 'Priority support', 'Free dedicated IP'],
        monthly: 449, quarterly: 1249, yearly: 4499
    },
    {
        name: 'VPS Nano', cat: 'vps', badge: 'Starter', accentIcon: 'server',
        description: 'A pocket-sized cloud server for side projects, bots and staging environments.',
        specs: { cpu: '2 vCPU Ryzen 9', ram: '4 GB DDR4', disk: '80 GB NVMe', bandwidth: '4 TB transfer', os: 'Linux / Windows', ip: '1 IPv4 + /64' },
        features: ['Full root access', 'NVMe SSD storage', 'Snapshots & backups', '10 Gbps uplink', 'Instant provisioning', '99.99% uptime SLA'],
        monthly: 349, quarterly: 999, yearly: 3499
    },
    {
        name: 'VPS Pro', cat: 'vps', badge: 'Most popular', accentIcon: 'server',
        description: 'Production-ready compute for web apps, game panels and CI pipelines that need to stay fast.',
        specs: { cpu: '4 vCPU Ryzen 9', ram: '8 GB DDR4', disk: '160 GB NVMe', bandwidth: '8 TB transfer', os: 'Linux / Windows', ip: '2 IPv4 + /64' },
        features: ['Full root access', 'NVMe SSD storage', 'Automatic snapshots', '10 Gbps uplink', 'Instant provisioning', '99.99% uptime SLA', 'Free weekly backup'],
        monthly: 649, quarterly: 1849, yearly: 6299
    },
    {
        name: 'VPS Elite', cat: 'vps', badge: 'Power', accentIcon: 'server',
        description: 'High-clock Ryzen cores and generous memory for databases, containers and busy APIs.',
        specs: { cpu: '8 vCPU Ryzen 9', ram: '16 GB DDR4', disk: '320 GB NVMe', bandwidth: '16 TB transfer', os: 'Linux / Windows', ip: '2 IPv4 + /64' },
        features: ['Full root access', 'NVMe SSD storage', 'Automatic snapshots', '10 Gbps uplink', 'Instant provisioning', '99.99% uptime SLA', 'Priority support', 'DDoS protection'],
        monthly: 1199, quarterly: 3399, yearly: 11499
    },
    {
        name: 'Web Starter', cat: 'web-hosting', badge: 'Starter', accentIcon: 'globe',
        description: 'Everything you need to put your first website online — fast, secure and effortless.',
        specs: { websites: '1 website', disk: '10 GB NVMe', cpu: '1 vCPU', ram: '1 GB', bandwidth: 'Unmetered', ssl: 'Free SSL' },
        features: ['Free SSL certificate', 'One-click WordPress', 'LiteSpeed web server', 'Free website migration', 'Daily backups', 'Email accounts'],
        monthly: 99, quarterly: 279, yearly: 999
    },
    {
        name: 'Web Business', cat: 'web-hosting', badge: 'Best value', accentIcon: 'globe',
        description: 'For growing businesses and agencies that need room, speed and staging environments.',
        specs: { websites: '25 websites', disk: '50 GB NVMe', cpu: '2 vCPU', ram: '2 GB', bandwidth: 'Unmetered', ssl: 'Free SSL' },
        features: ['Free SSL certificate', 'One-click WordPress', 'LiteSpeed web server', 'Free website migration', 'Daily backups', 'Unlimited email accounts', 'Staging environments'],
        monthly: 199, quarterly: 559, yearly: 1999
    },
    {
        name: 'Bare Metal M1', cat: 'dedicated-servers', badge: 'Bare metal', accentIcon: 'cpu',
        description: 'A whole AMD Ryzen 9 server, all yours. No virtualisation, no shared cores, no limits.',
        specs: { cpu: 'Ryzen 9 7950X', ram: '128 GB DDR5', disk: '2 x 1 TB NVMe', bandwidth: '1 Gbps unmetered', raid: 'Hardware RAID', ip: '/29 subnet' },
        features: ['Full hardware access', 'IPMI / KVM console', 'Hardware RAID', '1 Gbps unmetered', 'Free setup', '24/7 smart hands'],
        monthly: 6499, quarterly: 18499, yearly: 62999
    },
    {
        name: 'Bare Metal M2', cat: 'dedicated-servers', badge: 'Enterprise', accentIcon: 'cpu',
        description: 'Dual EPYC cores with 10 Gbps networking for clusters, databases and heavy workloads.',
        specs: { cpu: '2 x AMD EPYC 9354', ram: '256 GB DDR5', disk: '4 TB NVMe', bandwidth: '10 Gbps unmetered', raid: 'Hardware RAID', ip: '/29 subnet' },
        features: ['Full hardware access', 'IPMI / KVM console', 'Hardware RAID', '10 Gbps unmetered', 'Free setup', 'Dedicated account manager', '99.99% uptime SLA'],
        monthly: 11999, quarterly: 33999, yearly: 119999
    }
];

const REVIEW_SEED = [
    { product: 1, rating: 5, comment: 'Setup took under a minute and the panel is buttery smooth. My SMP has zero lag with 30 players online.' },
    { product: 1, rating: 5, comment: 'Moved from another host and the difference is night and day. TPS stays at 20.0 all day.' },
    { product: 4, rating: 5, comment: 'Cheapest Ryzen VPS I could find in India, and disk speed is genuinely NVMe. Very happy.' },
    { product: 4, rating: 4, comment: 'Great value. Support answered in about ten minutes at 2am, which is impressive.' },
    { product: 7, rating: 5, comment: 'Free SSL, one-click WordPress and the site loads instantly. Perfect for my portfolio.' },
    { product: 7, rating: 4, comment: 'Solid hosting for the price. Migration was handled for me within a couple of hours.' }
];

async function seed() {
    const categoryCount = await dbGet('SELECT COUNT(*) AS c FROM categories');
    const settingsDefaults = [
        ['site_name', 'SiftNodes', 'Site name'],
        ['site_description', 'Premium Minecraft, VPS and web hosting on Ryzen 9 and NVMe. Deploy in 60 seconds.', 'Meta description'],
        ['contact_email', 'support@unixservice.in', 'Support email'],
        ['currency_name', 'Coins', 'Currency name'],
        ['currency_icon', '', 'Currency icon (optional emoji)'],
        ['upi_id', 'unixservice@upi', 'UPI ID for payments'],
        ['coin_value', '1', 'Value of 1 coin (INR)'],
        ['site_logo', '', 'Logo'],
        ['site_favicon', '', 'Favicon'],
        ['maintenance_mode', 'off', 'Maintenance mode'],
        ['maintenance_message', 'We are upgrading our network. We will be back shortly.', 'Maintenance message']
    ];
    for (const [key, value, description] of settingsDefaults) {
        await runDb('INSERT OR IGNORE INTO settings (key, value, description) VALUES (?, ?, ?)', [key, value, description]);
    }

    if (categoryCount.c > 0) return; // already seeded

    const catIds = {};
    for (const c of CATEGORY_SEED) {
        const id = uuidv4();
        catIds[c.slug] = id;
        await runDb(
            `INSERT INTO categories (id, name, slug, description, icon, accent, sortOrder, isActive)
             VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
            [id, c.name, c.slug, c.description, c.icon, c.accent, c.sort]
        );
    }

    // ---- demo users ----
    const hash = bcrypt.hashSync('password123', 10);
    const demoId = uuidv4();
    const joined = (days) => moment().subtract(days, 'days').format('YYYY-MM-DD HH:mm:ss');
    await runDb(
        `INSERT INTO users (id, email, password, firstName, lastName, phone, address, city, state, postalCode, coins, isAdmin, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`,
        [demoId, 'demo@unixservice.in', hash, 'Aarav', 'Sharma', '+91 98765 43210', '14, Tech Park Road', 'Durgapur', 'West Bengal', '713201', 2500, joined(214)]
    );
    const adminId = uuidv4();
    await runDb(
        `INSERT INTO users (id, email, password, firstName, lastName, coins, isAdmin, createdAt) VALUES (?, ?, ?, ?, ?, 0, 1, ?)`,
        [adminId, 'admin@unixservice.in', hash, 'Unix', 'Support', joined(240)]
    );
    const reviewerIds = [];
    const reviewers = [
        ['Riya', 'Kapoor', 'riya@example.com'],
        ['Kabir', 'Malhotra', 'kabir@example.com'],
        ['Ananya', 'Iyer', 'ananya@example.com']
    ];
    const reviewerJoinDays = [96, 58, 21];
    for (let idx = 0; idx < reviewers.length; idx++) {
        const [first, last, email] = reviewers[idx];
        const id = uuidv4();
        reviewerIds.push(id);
        await runDb(
            `INSERT INTO users (id, email, password, firstName, lastName, coins, createdAt) VALUES (?, ?, ?, ?, ?, 0, ?)`,
            [id, email, hash, first, last, joined(reviewerJoinDays[idx] || 30)]
        );
    }

    // ---- coin packages ----
    const packages = [
        ['Starter Pack', 'A top-up for a small project', 500, 450],
        ['Creator Pack', 'Best value for solo builders', 1200, 999],
        ['Studio Pack', 'For agencies and teams', 3000, 2399],
        ['Scale Pack', 'Maximum savings per coin', 8000, 5999]
    ];
    const packageIds = [];
    for (const [name, description, coins, price] of packages) {
        const id = uuidv4();
        packageIds.push(id);
        await runDb(
            `INSERT INTO coin_packages (id, name, description, coins, price) VALUES (?, ?, ?, ?, ?)`,
            [id, name, description, coins, price]
        );
    }

    // ---- products ----
    const productIds = [];
    for (const p of PRODUCT_SEED) {
        const id = uuidv4();
        productIds.push(id);
        await runDb(
            `INSERT INTO products (id, name, description, categoryId, specs, features, priceMonthly, priceQuarterly, priceYearly, isActive)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
            [id, p.name, p.description, catIds[p.cat], JSON.stringify(p.specs), JSON.stringify(p.features), p.monthly, p.quarterly, p.yearly]
        );
    }

    // ---- notes (shown on order pages) ----
    const notes = [
        'Your server is provisioned. Login details were sent to your email — happy building!',
        'Welcome aboard! Reply to your welcome email if you need a hand with setup.',
        'Your service is now active. Don\'t forget to enable automatic backups in the panel.'
    ];
    for (const productId of productIds) {
        await runDb('INSERT INTO product_notes (id, productId, note) VALUES (?, ?, ?)', [uuidv4(), productId, notes[Math.floor(Math.random() * notes.length)]]);
    }

    // ---- coupons ----
    await runDb(`INSERT INTO coupons (id, code, couponType, value, maxUses, expiresAt, isActive, createdAt)
                 VALUES (?, 'UNIX25', 'percent', 25, 500, ?, 1, ?)`,
        [uuidv4(), moment().add(60, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(34, 'days').format('YYYY-MM-DD HH:mm:ss')]);
    await runDb(`INSERT INTO coupons (id, code, couponType, value, maxUses, expiresAt, isActive, createdAt)
                 VALUES (?, 'LAUNCH100', 'fixed', 100, 200, ?, 1, ?)`,
        [uuidv4(), moment().add(30, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(12, 'days').format('YYYY-MM-DD HH:mm:ss')]);

    // ---- reviews ----
    for (let i = 0; i < REVIEW_SEED.length; i++) {
        const r = REVIEW_SEED[i];
        await runDb(
            `INSERT INTO reviews (id, productId, userId, rating, comment, isApproved, createdAt)
             VALUES (?, ?, ?, ?, ?, 1, ?)`,
            [uuidv4(), productIds[r.product], reviewerIds[i % reviewerIds.length], r.rating, r.comment, moment().subtract(i * 3 + 2, 'days').format('YYYY-MM-DD HH:mm:ss')]
        );
    }

    // one review awaiting moderation, so the admin queue is never empty
    await runDb(
        `INSERT INTO reviews (id, productId, userId, rating, comment, isApproved, createdAt)
         VALUES (?, ?, ?, 4, ?, 0, ?)`,
        [uuidv4(), productIds[2], reviewerIds[2],
         'Performance is brilliant, though I wish the panel had dark mode by default. Support answered in minutes.',
         moment().subtract(5, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );

    // ---- likes ----
    await runDb('INSERT INTO likes (id, productId, userId) VALUES (?, ?, ?)', [uuidv4(), productIds[1], demoId]);
    await runDb('INSERT INTO likes (id, productId, userId) VALUES (?, ?, ?)', [uuidv4(), productIds[4], demoId]);

    // ---- orders ----
    // A spread of statuses so every admin filter has something to show.
    const customerIds = [demoId, ...reviewerIds];
    const orderSeed = [
        { product: 1, cycle: 'monthly', status: 'active', daysAgo: 6 },
        { product: 4, cycle: 'yearly', status: 'active', daysAgo: 41 },
        { product: 7, cycle: 'quarterly', status: 'suspended', daysAgo: 96 },
        { product: 0, cycle: 'monthly', status: 'pending', daysAgo: 0, user: 1, discountPct: 25, note: 'First Minecraft server for our SMP — please provision in Mumbai.' },
        { product: 9, cycle: 'yearly', status: 'pending', daysAgo: 1, user: 2, note: 'Annual billing approved by finance.' },
        { product: 5, cycle: 'yearly', status: 'active', daysAgo: 18, user: 2 },
        { product: 8, cycle: 'monthly', status: 'completed', daysAgo: 130, user: 3 },
        { product: 6, cycle: 'monthly', status: 'active', daysAgo: 4, user: 3 },
        { product: 2, cycle: 'quarterly', status: 'cancelled', daysAgo: 55, user: 0, discountPct: 10, note: 'Switched to a different plan.' }
    ];
    for (const o of orderSeed) {
        const p = PRODUCT_SEED[o.product];
        const listPrice = o.cycle === 'monthly' ? p.monthly : o.cycle === 'quarterly' ? p.quarterly : p.yearly;
        const discount = o.discountPct ? Math.round(listPrice * o.discountPct / 100) : 0;
        const finalPrice = listPrice - discount;
        const stamp = moment().subtract(o.daysAgo, 'days').format('YYYY-MM-DD HH:mm:ss');
        await runDb(
            `INSERT INTO orders (id, userId, productId, productName, productCategory, billingCycle, originalPrice, discount, price, note, paymentMethod, status, createdAt, updatedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'coins', ?, ?, ?)`,
            [uuidv4(), customerIds[o.user || 0], productIds[o.product], p.name,
             CATEGORY_SEED.find((c) => c.slug === p.cat).name, o.cycle, listPrice, discount, finalPrice,
             o.note || notes[0], o.status, stamp, stamp]
        );
    }

    // ---- coin transactions ----
    await runDb(
        `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, upiId, adminVerified, verifiedAt, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, 'completed', 'demo@upi', 1, ?, ?)`,
        [uuidv4(), demoId, packageIds[1], 'TXN' + Date.now().toString(36).toUpperCase(), 999, 1200, moment().subtract(20, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(20, 'days').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, upiId, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, 'pending', 'demo@upi', ?)`,
        [uuidv4(), demoId, packageIds[0], 'TXN' + (Date.now() + 1).toString(36).toUpperCase(), 450, 500, moment().subtract(1, 'days').format('YYYY-MM-DD HH:mm:ss')]
    );

    // extra pending / completed top-ups from other customers
    await runDb(
        `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, upiId, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, 'pending', 'riya@upi', ?)`,
        [uuidv4(), reviewerIds[0], packageIds[1], 'TXN' + (Date.now() + 7).toString(36).toUpperCase(), 999, 1200,
         moment().subtract(4, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, upiId, adminVerified, verifiedAt, createdAt)
         VALUES (?, ?, ?, ?, ?, ?, 'completed', 'kabir@upi', 1, ?, ?)`,
        [uuidv4(), reviewerIds[1], packageIds[2], 'TXN' + (Date.now() + 9).toString(36).toUpperCase(), 2399, 3000,
         moment().subtract(11, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(11, 'days').format('YYYY-MM-DD HH:mm:ss')]
    );

    // ---- tickets ----
    const ticket1 = 'TKT-DEMO001';
    const ticket2 = 'TKT-DEMO002';
    await runDb(
        `INSERT INTO tickets (id, userId, subject, description, department, priority, status, tags, isReadUser, isReadAdmin, createdAt, updatedAt, slaDue)
         VALUES (?, ?, ?, ?, 'technical', 'high', 'open', 'minecraft,performance', 1, 0, ?, ?, ?)`,
        [ticket1, demoId, 'Server TPS drops after installing plugins', 'After installing a few plugins my TPS drops to around 12 with 15 players online. Any advice on profiling?', moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(6, 'hours').format('YYYY-MM-DD HH:mm:ss'), moment().add(2, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments, isAdminReply, isNote, createdAt) VALUES (?, ?, ?, ?, '[]', 1, 0, ?)`,
        [uuidv4(), ticket1, adminId, 'Thanks for reaching out! Could you share your plugin list and a Spark profiler link? That usually pinpoints the lag source within minutes.', moment().subtract(6, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO tickets (id, userId, subject, description, department, priority, status, tags, isReadUser, isReadAdmin, createdAt, updatedAt, slaDue)
         VALUES (?, ?, ?, ?, 'billing', 'medium', 'resolved', 'payment', 1, 1, ?, ?, ?)`,
        [ticket2, demoId, 'Coin top-up not reflected on dashboard', 'I topped up 1,200 coins yesterday. The payment left my bank but my balance still shows the old amount.', moment().subtract(9, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(8, 'days').format('YYYY-MM-DD HH:mm:ss'), moment().subtract(9, 'days').add(24, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments, isAdminReply, isNote, createdAt) VALUES (?, ?, ?, ?, '[]', 1, 0, ?)`,
        [uuidv4(), ticket2, adminId, 'We verified your UPI reference and credited the coins. You should see the balance updated now. Sorry for the delay!', moment().subtract(8, 'days').format('YYYY-MM-DD HH:mm:ss')]
    );

    // ---- extra tickets from other customers ----
    const ticket3 = 'TKT-DEMO003';
    const ticket4 = 'TKT-DEMO004';
    await runDb(
        `INSERT INTO tickets (id, userId, subject, description, department, priority, status, tags, isReadUser, isReadAdmin, createdAt, updatedAt, slaDue)
         VALUES (?, ?, ?, ?, 'billing', 'high', 'open', 'payment,invoice', 1, 0, ?, ?, ?)`,
        [ticket3, reviewerIds[0], 'Invoice shows the wrong GSTIN',
         'Our accountant needs the company GSTIN printed on the invoice for the last two renewals. Can you reissue them?',
         moment().subtract(9, 'hours').format('YYYY-MM-DD HH:mm:ss'),
         moment().subtract(3, 'hours').format('YYYY-MM-DD HH:mm:ss'),
         moment().add(5, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO tickets (id, userId, subject, description, department, priority, status, tags, isReadUser, isReadAdmin, createdAt, updatedAt, slaDue)
         VALUES (?, ?, ?, ?, 'sales', 'medium', 'in_progress', 'feature', 0, 1, ?, ?, ?)`,
        [ticket4, reviewerIds[1], 'Do you offer a reseller discount?',
         'We run a small web agency and would move roughly 40 sites here. Is there a partner or volume pricing tier?',
         moment().subtract(2, 'days').format('YYYY-MM-DD HH:mm:ss'),
         moment().subtract(1, 'day').format('YYYY-MM-DD HH:mm:ss'),
         moment().subtract(2, 'days').add(24, 'hours').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments, isAdminReply, isNote, createdAt) VALUES (?, ?, ?, ?, '[]', 1, 0, ?)`,
        [uuidv4(), ticket4, adminId, 'Absolutely — we have a partner tier starting at 25 sites. I have emailed the rate card and a migration checklist.',
         moment().subtract(1, 'day').format('YYYY-MM-DD HH:mm:ss')]
    );
    await runDb(
        'INSERT INTO ticket_notes (id, ticketId, userId, message) VALUES (?, ?, ?, ?)',
        [uuidv4(), ticket4, adminId, 'Partner rate card sent. Follow up on Thursday if they have not replied.']
    );

    // ---- demo analytics traffic (14 days) ----
    const visitPages = ['/view', '/view', '/products', '/products', '/c/minecraft', '/c/vps', '/c/web-hosting', '/login', '/register', '/store'];
    const visitCountries = ['IN', 'IN', 'IN', 'US', 'US', 'GB', 'DE', 'SG', 'AE', 'CA', 'AU', 'BR'];
    const visitAgents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15',
        'Mozilla/5.0 (X11; Linux x86_64; rv:132.0) Gecko/20100101 Firefox/132.0',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0 Safari/537.36 Edg/141.0'
    ];
    for (let d = 13; d >= 0; d--) {
        const weekday = moment().subtract(d, 'days').day();
        const base = 26 + Math.round(Math.sin(d / 2.4) * 8) + (weekday === 0 || weekday === 6 ? 10 : 0);
        const count = Math.max(9, base + Math.round(Math.random() * 14));
        for (let i = 0; i < count; i++) {
            const ts = moment().subtract(d, 'days').startOf('day')
                .add(6 + Math.floor(Math.random() * 17), 'hours')
                .add(Math.floor(Math.random() * 60), 'minutes');
            if (ts.isAfter(moment())) continue;
            await runDb(
                'INSERT INTO visits (id, ip, country, page, user_agent, timestamp, is_bot) VALUES (?, ?, ?, ?, ?, ?, 0)',
                [uuidv4(), `10.24.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
                 visitCountries[Math.floor(Math.random() * visitCountries.length)],
                 visitPages[Math.floor(Math.random() * visitPages.length)],
                 visitAgents[Math.floor(Math.random() * visitAgents.length)],
                 ts.format('YYYY-MM-DD HH:mm:ss')]
            );
        }
        for (let i = 0; i < 3; i++) {
            await runDb(
                'INSERT INTO visits (id, ip, country, page, user_agent, timestamp, is_bot) VALUES (?, ?, ?, ?, ?, ?, 1)',
                [uuidv4(), '66.249.66.' + Math.floor(Math.random() * 255), 'US', '/view',
                 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
                 moment().subtract(d, 'days').add(3, 'hours').format('YYYY-MM-DD HH:mm:ss')]
            );
        }
    }
}

// =========================================================
//  APP
// =========================================================
const app = express();
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('trust proxy', 1);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SESSION_SECRET || 'unix-service-demo-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        secure: false,
        sameSite: 'lax',
        maxAge: 1000 * 60 * 60 * 24 * 7
    }
}));
app.use(flash());

// ---------- uploads ----------
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => cb(null, `${Date.now()}-${uuidv4()}${path.extname(file.originalname)}`)
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => file.mimetype.startsWith('image/') ? cb(null, true) : cb(new Error('Images only')) });
const screenshotUpload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => file.mimetype.startsWith('image/') ? cb(null, true) : cb(new Error('Images only')) });
const ticketUpload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024, files: 5 } });

// inline coin artwork (avoids emoji-font gaps across platforms)
const COIN_ICON = "data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2024%2024'%3E%3Cdefs%3E%3ClinearGradient%20id='c'%20x1='0'%20y1='0'%20x2='1'%20y2='1'%3E%3Cstop%20offset='0'%20stop-color='%23f59e0b'/%3E%3Cstop%20offset='1'%20stop-color='%23fcd34d'/%3E%3C/linearGradient%3E%3C/defs%3E%3Ccircle%20cx='12'%20cy='12'%20r='10.5'%20fill='url(%23c)'/%3E%3Ccircle%20cx='12'%20cy='12'%20r='7.9'%20fill='none'%20stroke='%2378350f'%20stroke-opacity='.3'%20stroke-width='1.1'/%3E%3Cpath%20d='M12%206.8v10.4M15%209.3c0-1.1-1.3-1.9-3-1.9s-3%20.8-3%201.9%201.3%201.9%203%201.9%203%20.8%203%201.9-1.3%201.9-3%201.9-3-.8-3-1.9'%20fill='none'%20stroke='%2378350f'%20stroke-opacity='.75'%20stroke-width='1.5'%20stroke-linecap='round'/%3E%3C/svg%3E";

// ---------- helpers ----------
const helpers = {
    sanitize: (str) => String(str == null ? '' : str).replace(/[<>]/g, '').trim(),
    initials: (first = '', last = '') => `${(first[0] || '')}${(last[0] || '')}`.toUpperCase() || 'U',
    paginate: (total, page = 1, perPage = 9) => {
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        return { total, page: Math.min(page, totalPages), perPage, totalPages, hasNext: page < totalPages, hasPrev: page > 1 };
    },
    countRows: async (table, where = '', params = []) => {
        const row = await dbGet(`SELECT COUNT(*) AS c FROM ${table} ${where}`, params);
        return row ? row.c : 0;
    },
    getCategoryStats: async () => dbAll(
        `SELECT c.*, COUNT(p.id) AS productCount
         FROM categories c LEFT JOIN products p ON p.categoryId = c.id AND p.isActive = 1
         WHERE c.isActive = 1 GROUP BY c.id ORDER BY c.sortOrder, c.name`
    ),
    getCategories: async () => dbAll('SELECT * FROM categories WHERE isActive = 1 ORDER BY sortOrder, name'),
    getAverageRating: async (productId) => {
        const r = await dbGet('SELECT AVG(rating) AS avg, COUNT(*) AS count FROM reviews WHERE productId = ? AND isApproved = 1', [productId]);
        return { average: r && r.avg ? Number(r.avg).toFixed(1) : null, count: r ? r.count : 0 };
    },
    getRandomNote: async (productId) => {
        const rows = await dbAll('SELECT note FROM product_notes WHERE productId = ? AND isActive = 1', [productId]);
        return rows.length ? rows[Math.floor(Math.random() * rows.length)].note : '';
    },
    generateTransactionId: () => 'TXN' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase(),
    formatDate: (d, fmt = 'DD MMM YYYY') => (d ? moment(d).format(fmt) : '—'),
    formatDateTime: (d) => (d ? moment(d).format('DD MMM YYYY, hh:mm A') : '—'),
    timeAgo: (d) => (d ? moment(d).fromNow() : '—'),
    cycleLabel: (c) => (c === 'yearly' ? 'per year' : c === 'quarterly' ? 'per quarter' : 'per month'),
    cycleMonths: (c) => (c === 'yearly' ? 12 : c === 'quarterly' ? 3 : 1)
};

const CATEGORY_ICON_FALLBACK = { minecraft: 'blocks', vps: 'server', 'web-hosting': 'globe', 'dedicated-servers': 'cpu' };
app.locals.iconForCategory = (slug) => CATEGORY_ICON_FALLBACK[slug] || 'server';
app.locals.initials = helpers.initials;
app.locals.iconForDepartment = (dept) => ({ billing: 'card', technical: 'tools', sales: 'bag', general: 'chat', support: 'headset' }[dept] || 'chat');

let cache = { categories: null, settings: null, at: 0 };
async function loadCategories() {
    if (cache.categories && Date.now() - cache.at < 15000) return cache.categories;
    const rows = await dbAll('SELECT * FROM categories WHERE isActive = 1 ORDER BY sortOrder, name');
    cache.categories = rows;
    cache.at = Date.now();
    return rows;
}

const TICKET_CONFIG = {
    PRIORITIES: ['low', 'medium', 'high', 'critical'],
    STATUSES: ['open', 'in_progress', 'on_hold', 'resolved', 'closed'],
    DEPARTMENTS: ['billing', 'technical', 'sales', 'general'],
    TAGS: ['bug', 'feature', 'payment', 'login', 'ui', 'api', 'urgent'],
    MAX_ATTACHMENTS: 5,
    SLA: { critical: 2, high: 8, medium: 24, low: 72 }
};

function calculateSLADueDate(priority) {
    const due = moment().add(TICKET_CONFIG.SLA[priority] || 24, 'hours');
    return due.format('YYYY-MM-DD HH:mm:ss');
}
function slaStatus(ticket) {
    if (!ticket.slaDue || ['closed', 'resolved'].includes(ticket.status)) return 'met';
    const hours = moment(ticket.slaDue).diff(moment(), 'hours', true);
    if (hours <= 0) return 'breached';
    if (hours <= 4) return 'warning';
    return 'ok';
}

// ---------- auth / admin guards ----------
function requireAdmin(req, res, next) {
    if (!req.session.authorised || !req.session.user || !req.session.user.isAdmin) {
        req.flash('error', 'Administrator sign-in required.');
        return res.redirect('/admin/login');
    }
    next();
}

const categoryUpload = upload;

async function getCategoryBySlug(slug) {
    const row = await dbGet('SELECT id FROM categories WHERE LOWER(slug) = LOWER(?) AND isActive = 1', [slug]);
    return row ? row.id : null;
}

async function upsertSetting(key, value, description = '') {
    const exists = await dbGet('SELECT 1 AS ok FROM settings WHERE key = ?', [key]);
    if (exists) {
        await runDb('UPDATE settings SET value = ? WHERE key = ?', [value, key]);
    } else {
        await runDb('INSERT INTO settings (key, value, description) VALUES (?, ?, ?)', [key, value, description]);
    }
}

// ---------- global locals ----------
app.use(async (req, res, next) => {
    try {
        const rows = await dbAll('SELECT key, value FROM settings');
        const settings = {};
        rows.forEach((r) => { settings[r.key] = r.value; });

        let user = null;
        if (req.session.authorised && req.session.user) {
            user = await dbGet('SELECT id, email, firstName, lastName, phone, address, city, state, postalCode, coins, isAdmin, createdAt, lastLogin FROM users WHERE id = ?', [req.session.user.id]);
            if (user) req.session.user = { ...req.session.user, ...user };
        }

        res.locals.settings = settings;
        res.locals.siteName = settings.site_name || 'SiftNodes';
        res.locals.siteDescription = settings.site_description || 'Premium hosting, deploy in 60 seconds.';
        res.locals.currencyName = settings.currency_name || 'Coins';
        res.locals.coinIcon = COIN_ICON;
        res.locals.currencyIcon = (settings.currency_icon && settings.currency_icon.trim() !== '🪙') ? settings.currency_icon : '';
        res.locals.supportEmail = settings.contact_email || 'support@unixservice.in';
        res.locals.upiId = settings.upi_id || '';
        res.locals.hasCustomLogo = Boolean(settings.site_logo && settings.site_logo.trim());
        res.locals.siteLogo = settings.site_logo || '';
        res.locals.hasCustomFavicon = Boolean(settings.site_favicon && settings.site_favicon.trim());
        res.locals.siteFavicon = settings.site_favicon || '';
        res.locals.maintenanceMode = settings.maintenance_mode === 'on';
        res.locals.maintenanceMessage = settings.maintenance_message || 'We are performing scheduled maintenance. We will be back shortly.';
        res.locals.user = user;
        res.locals.isLoggedIn = Boolean(user);
        res.locals.navCategories = await loadCategories();
        res.locals.moment = moment;
        res.locals.h = helpers;
        res.locals.TICKET_CONFIG = TICKET_CONFIG;
        res.locals.slaStatus = slaStatus;
        res.locals.success = req.flash('success');
        res.locals.error = req.flash('error');
        res.locals.currentPath = req.path;
        res.locals.year = new Date().getFullYear();
        res.locals.pageTitle = '';
        next();
    } catch (err) {
        next(err);
    }
});

// maintenance mode (admins bypass)
app.use((req, res, next) => {
    if (!res.locals.maintenanceMode) return next();
    if (res.locals.user && res.locals.user.isAdmin) return next();
    if (req.path.startsWith('/css') || req.path.startsWith('/js') || req.path.startsWith('/uploads') || req.path === '/login' || req.path === '/logout') return next();
    if (req.path === '/maintenance') return next();
    return res.status(503).render('maintenance', { title: 'Scheduled maintenance', activePage: '', hideCta: true });
});

// ---------- analytics: lightweight page-view tracking ----------
app.use((req, res, next) => {
    if (req.method !== 'GET') return next();
    if (req.path.startsWith('/admin') || req.path.startsWith('/api') ||
        req.path.startsWith('/css') || req.path.startsWith('/js') || req.path.startsWith('/uploads')) {
        return next();
    }
    try {
        const ua = req.headers['user-agent'] || '';
        const isBot = /bot|crawl|spider|googlebot|bingbot|yandex|slurp|facebookexternalhit|semrush/i.test(ua);
        const ip = String(req.headers['x-forwarded-for'] || req.ip || 'unknown').split(',')[0].trim();
        const country = req.headers['cf-ipcountry'] || req.headers['x-country'] || 'IN';
        runDb(
            'INSERT INTO visits (id, ip, country, page, user_agent, timestamp, is_bot) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [uuidv4(), ip, country, req.path, ua.slice(0, 400), moment().format('YYYY-MM-DD HH:mm:ss'), isBot ? 1 : 0]
        ).catch(() => {});
    } catch (e) { /* never block a page for analytics */ }
    next();
});

// ---------- auth middleware ----------
function requireAuth(req, res, next) {
    if (!req.session.authorised || !req.session.user) {
        req.flash('error', 'Please sign in to continue.');
        return res.redirect(`/login?redirect=${encodeURIComponent(req.originalUrl)}`);
    }
    next();
}
function requireGuest(req, res, next) {
    if (req.session.authorised) return res.redirect('/dashboard');
    next();
}

async function processProducts(products) {
    return Promise.all(products.map(async (p) => {
        let specs = {};
        let features = [];
        try { specs = JSON.parse(p.specs || '{}'); } catch (e) { specs = {}; }
        try { features = JSON.parse(p.features || '[]'); } catch (e) { features = []; }
        const rating = await helpers.getAverageRating(p.id);
        return {
            ...p,
            specs,
            features,
            note: p.note || '',
            averageRating: rating.average,
            reviewCount: rating.count,
            icon: p.categoryIcon || CATEGORY_ICON_FALLBACK[p.categorySlug] || 'server',
            accent: p.categoryAccent || '#7c5cff'
        };
    }));
}

const PRODUCT_LIST_SQL = `
    SELECT p.*, c.name AS categoryName, c.slug AS categorySlug, c.icon AS categoryIcon, c.accent AS categoryAccent
    FROM products p LEFT JOIN categories c ON p.categoryId = c.id
    WHERE p.isActive = 1`;

async function getProduct(id, userId = null) {
    const row = await dbGet(`${PRODUCT_LIST_SQL} AND p.id = ?`, [id]);
    if (!row) return null;
    const [product] = await processProducts([row]);
    if (userId) {
        const like = await dbGet('SELECT id FROM likes WHERE productId = ? AND userId = ?', [id, userId]);
        product.isLiked = Boolean(like);
    } else {
        product.isLiked = false;
    }
    const notes = await dbAll('SELECT note FROM product_notes WHERE productId = ? AND isActive = 1', [id]);
    product.note = notes.length ? notes[Math.floor(Math.random() * notes.length)].note : '';
    return product;
}

function pageMeta(title, activePage) {
    return { title, activePage };
}

// static content used across views
const CONTENT = {
    whyUs: [
        { icon: 'zap', title: 'Deploys in 60 seconds', text: 'Provisioning is fully automated. Your server, VPS or website is live before your coffee cools.' },
        { icon: 'shield', title: 'DDoS protection built in', text: 'Every plan sits behind 2.4 Tbps of always-on filtering across three scrubbing centres.' },
        { icon: 'cpu', title: 'Ryzen 9 & NVMe only', text: 'No recycled enterprise hardware. Fast cores, DDR5 memory and NVMe disks in every node.' },
        { icon: 'headset', title: 'Humans, 24/7', text: 'Real engineers on live chat and tickets around the clock. Median first reply: 4 minutes.' },
        { icon: 'globe', title: 'Global footprint', text: 'Nine regions across India, Singapore, Frankfurt, London, New York and São Paulo.' },
        { icon: 'refresh', title: 'Free migrations', text: 'Moving from another host? Our team migrates your sites and servers for free, usually same-day.' }
    ],
    testimonials: [
        { name: 'Ishaan Verma', role: 'Owner, CraftHaven SMP', initials: 'IV', rating: 5, text: 'We moved 90 players over during a Friday night event and never dropped a single TPS tick. The panel alone is worth the price.' },
        { name: 'Meera Nair', role: 'Founder, Studio Kaapi', initials: 'MN', rating: 5, text: 'Deployed our staging and production VPS in one afternoon. Support answered in four minutes at midnight — actual engineers, not scripts.' },
        { name: 'Dev Patel', role: 'Freelance developer', initials: 'DP', rating: 4, text: 'The ₹99 plan is genuinely good. LiteSpeed makes my client sites feel instant, and migrations were handled for me.' }
    ],
    faqs: [
        { q: 'How fast is setup?', a: 'Automated deployment means your service is live within about 60 seconds of payment. VPS and dedicated nodes are usually online in under 5 minutes.' },
        { q: 'Do I need a domain name?', a: 'Not at all. Every Minecraft and web hosting plan includes a free subdomain. You can connect a custom domain whenever you are ready.' },
        { q: 'What is the Coins system?', a: 'Coins are the wallet currency used in this store (1 coin = ₹1). Top up once and spend across any plan, upgrade or renewal — no repeated checkout.' },
        { q: 'Can I upgrade my plan later?', a: 'Yes. You can upgrade at any time from your dashboard and we only charge the prorated difference. Downgrades apply at the next renewal.' },
        { q: 'Do you offer refunds?', a: 'Every plan includes a 7-day money-back guarantee. If we are not the right fit, open a ticket and we will refund the coins to your wallet.' },
        { q: 'Where are your servers located?', a: 'We operate nine regions: Mumbai, Delhi, Singapore, Tokyo, Frankfurt, London, New York, Dallas and São Paulo. You can pick a location at checkout.' }
    ],
    steps: [
        { n: '01', title: 'Pick a plan', text: 'Choose a Minecraft, VPS, web or bare-metal plan that fits your workload.' },
        { n: '02', title: 'Pay with coins', text: 'Top up your wallet with UPI in seconds, then checkout in one click.' },
        { n: '03', title: 'Deploy & build', text: 'Your service is provisioned instantly. Log in to the panel and ship.' }
    ]
};

const CATEGORY_GRADIENTS = { minecraft: '#8b5cf6', vps: '#22d3ee', 'web-hosting': '#34d399', 'dedicated-servers': '#f59e0b' };

// =========================================================
//  PUBLIC ROUTES
// =========================================================
app.get('/', (req, res) => res.redirect('/view'));

app.get('/view', async (req, res, next) => {
    try {
        const categories = await helpers.getCategoryStats();
        const recent = await dbAll(`${PRODUCT_LIST_SQL} ORDER BY p.createdAt DESC LIMIT 6`);
        const products = await processProducts(recent);
        const stats = {
            products: await helpers.countRows('products', 'WHERE isActive = 1'),
            customers: 2400,
            regions: 9,
            uptime: '99.99%'
        };
        res.render('users/view', {
            ...pageMeta('Premium hosting, expertly built', 'home'),
            categories,
            products,
            stats,
            whyUs: CONTENT.whyUs,
            testimonials: CONTENT.testimonials,
            faqs: CONTENT.faqs,
            steps: CONTENT.steps
        });
    } catch (err) { next(err); }
});

app.get('/c/:cat', async (req, res, next) => {
    try {
        const slug = helpers.sanitize(req.params.cat);
        const category = await dbGet('SELECT * FROM categories WHERE slug = ? AND isActive = 1', [slug]);
        if (!category) {
            req.flash('error', 'Category not found.');
            return res.redirect('/products');
        }
        const page = Math.max(1, parseInt(req.query.page, 10) || 1);
        const perPage = 9;
        const sort = ['newest', 'price_low', 'price_high'].includes(req.query.sort) ? req.query.sort : 'newest';
        const orderBy = sort === 'price_low' ? 'p.priceMonthly ASC' : sort === 'price_high' ? 'p.priceMonthly DESC' : 'p.createdAt DESC';

        const total = await helpers.countRows('products', 'WHERE isActive = 1 AND categoryId = ?', [category.id]);
        const pagination = helpers.paginate(total, page, perPage);
        const rows = await dbAll(
            `${PRODUCT_LIST_SQL} AND p.categoryId = ? ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
            [category.id, perPage, (pagination.page - 1) * perPage]
        );
        const products = await processProducts(rows);
        const categories = await helpers.getCategoryStats();
        res.render('users/products', {
            ...pageMeta(category.name, 'products'),
            heading: category.name,
            subheading: category.description,
            eyebrow: 'Hosting category',
            category,
            currentCategory: category.slug,
            categories,
            products,
            pagination,
            filters: { category: category.slug, search: '', sort },
            baseUrl: `/c/${category.slug}`
        });
    } catch (err) { next(err); }
});

app.get('/products', async (req, res, next) => {
    try {
        const page = Math.max(1, parseInt(req.query.page, 10) || 1);
        const perPage = 9;
        const search = helpers.sanitize(req.query.search || '');
        const categorySlug = helpers.sanitize(req.query.category || '');
        const sort = ['newest', 'price_low', 'price_high', 'popular'].includes(req.query.sort) ? req.query.sort : 'newest';

        let where = 'WHERE p.isActive = 1';
        const params = [];
        let category = null;
        if (search) {
            where += ' AND (p.name LIKE ? OR p.description LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }
        if (categorySlug) {
            category = await dbGet('SELECT * FROM categories WHERE slug = ? AND isActive = 1', [categorySlug]);
            if (category) {
                where += ' AND p.categoryId = ?';
                params.push(category.id);
            }
        }
        const totalRow = await dbGet(`SELECT COUNT(*) AS c FROM products p ${where}`, params);
        const pagination = helpers.paginate(totalRow ? totalRow.c : 0, page, perPage);
        const orderBy = sort === 'price_low' ? 'p.priceMonthly ASC'
            : sort === 'price_high' ? 'p.priceMonthly DESC'
            : sort === 'popular' ? '(SELECT COUNT(*) FROM likes l WHERE l.productId = p.id) DESC, p.createdAt DESC'
            : 'p.createdAt DESC';
        const rows = await dbAll(
            `${PRODUCT_LIST_SQL.replace('WHERE p.isActive = 1', where)} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
            [...params, perPage, (pagination.page - 1) * perPage]
        );
        const products = await processProducts(rows);
        const categories = await helpers.getCategoryStats();
        res.render('users/products', {
            ...pageMeta(search ? `Search: ${search}` : 'All hosting plans', 'products'),
            heading: search ? `Results for "${search}"` : category ? category.name : 'Every plan, one place',
            subheading: category ? category.description : 'Minecraft, VPS, web and bare-metal hosting — all on Ryzen 9 and NVMe. Pick a plan or filter by category.',
            eyebrow: 'Hosting catalogue',
            category,
            currentCategory: categorySlug || 'all',
            categories,
            products,
            pagination,
            filters: { category: categorySlug, search, sort },
            baseUrl: '/products'
        });
    } catch (err) { next(err); }
});

app.get('/products/:id', async (req, res, next) => {
    try {
        const userId = req.session.user ? req.session.user.id : null;
        const product = await getProduct(req.params.id, userId);
        if (!product) {
            req.flash('error', 'That product could not be found.');
            return res.redirect('/products');
        }
        const relatedRows = await dbAll(`${PRODUCT_LIST_SQL} AND p.categoryId = ? AND p.id != ? ORDER BY p.priceMonthly ASC LIMIT 3`, [product.categoryId, product.id]);
        const related = await processProducts(relatedRows);
        const reviews = await dbAll(
            `SELECT r.*, u.firstName, u.lastName FROM reviews r JOIN users u ON r.userId = u.id
             WHERE r.productId = ? AND r.isApproved = 1 ORDER BY r.createdAt DESC LIMIT 6`,
            [product.id]
        );
        const distribution = await dbAll(
            `SELECT rating, COUNT(*) AS c FROM reviews WHERE productId = ? AND isApproved = 1 GROUP BY rating`,
            [product.id]
        );
        const canReview = Boolean(userId) && !(await dbGet('SELECT id FROM reviews WHERE productId = ? AND userId = ?', [product.id, userId]));
        res.render('users/product-detail', {
            ...pageMeta(product.name, 'products'),
            product,
            related,
            reviews,
            distribution,
            canReview
        });
    } catch (err) { next(err); }
});

// Legacy / pretty category product URL → canonical product page
app.get('/c/:cat/:id', async (req, res) => {
    res.redirect(301, `/products/${encodeURIComponent(req.params.id)}`);
});

app.post('/products/:id/like', requireAuth, async (req, res, next) => {
    try {
        const productId = req.params.id;
        const userId = req.session.user.id;
        const existing = await dbGet('SELECT id FROM likes WHERE productId = ? AND userId = ?', [productId, userId]);
        if (existing) {
            await runDb('DELETE FROM likes WHERE id = ?', [existing.id]);
            return res.json({ liked: false });
        }
        await runDb('INSERT INTO likes (id, productId, userId) VALUES (?, ?, ?)', [uuidv4(), productId, userId]);
        res.json({ liked: true });
    } catch (err) { next(err); }
});

app.post('/products/:id/review', requireAuth, async (req, res, next) => {
    try {
        const { rating, comment } = req.body;
        const productId = req.params.id;
        const userId = req.session.user.id;
        const value = parseInt(rating, 10);
        if (!value || value < 1 || value > 5) {
            req.flash('error', 'Please choose a rating between 1 and 5.');
            return res.redirect(`/products/${productId}#reviews`);
        }
        if (comment && comment.length > 1000) {
            req.flash('error', 'Your review is too long (max 1000 characters).');
            return res.redirect(`/products/${productId}#reviews`);
        }
        const existing = await dbGet('SELECT id FROM reviews WHERE productId = ? AND userId = ?', [productId, userId]);
        if (existing) {
            req.flash('error', 'You have already reviewed this plan.');
            return res.redirect(`/products/${productId}#reviews`);
        }
        await runDb(
            'INSERT INTO reviews (id, productId, userId, rating, comment, isApproved) VALUES (?, ?, ?, ?, ?, 1)',
            [uuidv4(), productId, userId, value, helpers.sanitize(comment || '')]
        );
        req.flash('success', 'Thanks for sharing your experience!');
        res.redirect(`/products/${productId}#reviews`);
    } catch (err) { next(err); }
});

// =========================================================
//  AUTH
// =========================================================
app.get('/login', requireGuest, (req, res) => {
    res.render('users/login', {
        ...pageMeta('Sign in', 'login'),
        redirectUrl: typeof req.query.redirect === 'string' ? req.query.redirect : ''
    });
});

app.post('/login', requireGuest, async (req, res, next) => {
    try {
        const { email, password, remember } = req.body;
        const redirectUrl = typeof req.body.redirectUrl === 'string' && req.body.redirectUrl.startsWith('/') ? req.body.redirectUrl : '/dashboard';
        const user = await dbGet('SELECT * FROM users WHERE email = ? AND isActive = 1', [String(email || '').toLowerCase().trim()]);
        if (!user || !bcrypt.compareSync(String(password || ''), user.password)) {
            if (user) {
                await runDb('UPDATE users SET loginAttempts = loginAttempts + 1 WHERE id = ?', [user.id]);
            }
            req.flash('error', 'Those credentials do not match our records.');
            return res.redirect('/login');
        }
        await runDb('UPDATE users SET loginAttempts = 0, lastLogin = CURRENT_TIMESTAMP, lastIp = ? WHERE id = ?', [req.ip, user.id]);
        req.session.authorised = true;
        req.session.user = {
            id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName,
            coins: user.coins, isAdmin: user.isAdmin
        };
        if (remember === 'on') req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30;
        req.flash('success', `Welcome back, ${user.firstName}!`);
        res.redirect(redirectUrl);
    } catch (err) { next(err); }
});

app.get('/register', requireGuest, (req, res) => {
    res.render('users/register', {
        ...pageMeta('Create your account', 'register'),
        formData: {}
    });
});

app.post('/register', requireGuest, async (req, res, next) => {
    try {
        const { email, password, confirmPassword, firstName, lastName, phone, terms } = req.body;
        const errors = [];
        if (!email || !password || !firstName || !lastName) errors.push('Please fill in all required fields.');
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('That email address looks invalid.');
        if (!password || password.length < 8) errors.push('Password must be at least 8 characters.');
        if (password !== confirmPassword) errors.push('Passwords do not match.');
        if (terms !== 'on') errors.push('Please accept the terms to continue.');
        if (errors.length) {
            return res.status(422).render('users/register', {
                ...pageMeta('Create your account', 'register'),
                formData: req.body,
                error: errors
            });
        }
        const existing = await dbGet('SELECT id FROM users WHERE email = ?', [String(email).toLowerCase().trim()]);
        if (existing) {
            return res.status(409).render('users/register', {
                ...pageMeta('Create your account', 'register'),
                formData: req.body,
                error: ['An account with that email already exists. Try signing in.']
            });
        }
        const id = uuidv4();
        await runDb(
            `INSERT INTO users (id, email, password, firstName, lastName, phone, coins) VALUES (?, ?, ?, ?, ?, ?, 150)`,
            [id, String(email).toLowerCase().trim(), bcrypt.hashSync(password, 10), helpers.sanitize(firstName), helpers.sanitize(lastName), helpers.sanitize(phone || '')]
        );
        req.flash('success', 'Account created — we added 150 welcome coins to your wallet. Sign in to get started.');
        res.redirect('/login');
    } catch (err) { next(err); }
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// =========================================================
//  STORE / COINS
// =========================================================
app.get('/store', requireAuth, async (req, res, next) => {
    try {
        const packages = await dbAll('SELECT * FROM coin_packages WHERE isActive = 1 ORDER BY coins');
        const transactions = await dbAll(
            'SELECT ct.*, cp.name AS packageName FROM coin_transactions ct LEFT JOIN coin_packages cp ON ct.packageId = cp.id WHERE ct.userId = ? ORDER BY ct.createdAt DESC LIMIT 8',
            [req.session.user.id]
        );
        let qrCodeData = null;
        if (res.locals.upiId) {
            try {
                qrCodeData = await QRCode.toDataURL(`upi://pay?pa=${res.locals.upiId}&pn=${encodeURIComponent(res.locals.siteName)}&cu=INR`, { margin: 1, width: 320, color: { dark: '#0b0b12', light: '#ffffff' } });
            } catch (e) { qrCodeData = null; }
        }
        const spentRow = await dbGet("SELECT SUM(amount) AS total FROM coin_transactions WHERE userId = ? AND status = 'completed'", [req.session.user.id]);
        res.render('users/store', {
            ...pageMeta('Coin store', 'store'),
            packages,
            transactions,
            qrCodeData,
            spent: spentRow && spentRow.total ? spentRow.total : 0,
            demoMode: DEMO_MODE
        });
    } catch (err) { next(err); }
});

app.post('/store/purchase', requireAuth, screenshotUpload.single('screenshot'), async (req, res, next) => {
    try {
        const { packageId, upiRef, notes } = req.body;
        const pkg = await dbGet('SELECT * FROM coin_packages WHERE id = ? AND isActive = 1', [packageId]);
        if (!pkg) {
            req.flash('error', 'Please choose a coin package.');
            return res.redirect('/store');
        }
        if (!upiRef || String(upiRef).trim().length < 4) {
            req.flash('error', 'Please include the UPI reference / transaction ID.');
            return res.redirect('/store');
        }
        if (!req.file) {
            req.flash('error', 'Please attach a screenshot of the payment.');
            return res.redirect('/store');
        }
        const txId = helpers.generateTransactionId();
        const userId = req.session.user.id;
        const status = DEMO_MODE ? 'completed' : 'pending';
        await runDb(
            `INSERT INTO coin_transactions (id, userId, packageId, transactionId, amount, coins, status, upiId, screenshot, notes, adminVerified, verifiedAt)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [uuidv4(), userId, pkg.id, txId, pkg.price, pkg.coins, status, helpers.sanitize(upiRef), `/uploads/${req.file.filename}`, helpers.sanitize(notes || ''), DEMO_MODE ? 1 : 0, DEMO_MODE ? moment().format('YYYY-MM-DD HH:mm:ss') : null]
        );
        if (DEMO_MODE) {
            await runDb('UPDATE users SET coins = coins + ? WHERE id = ?', [pkg.coins, userId]);
            req.flash('success', `Payment verified (demo mode) — ${pkg.coins} coins have been added to your wallet.`);
        } else {
            req.flash('success', 'Payment submitted. Our team will verify it within 15 minutes.');
        }
        res.redirect('/store');
    } catch (err) { next(err); }
});

// =========================================================
//  ORDERS
// =========================================================
function priceForCycle(product, cycle) {
    return cycle === 'yearly' ? product.priceYearly : cycle === 'quarterly' ? product.priceQuarterly : product.priceMonthly;
}

app.post('/orders', requireAuth, async (req, res, next) => {
    try {
        const { productId, billingCycle, couponCode } = req.body;
        const cycle = ['monthly', 'quarterly', 'yearly'].includes(billingCycle) ? billingCycle : 'monthly';
        const userId = req.session.user.id;
        const product = await getProduct(productId);
        if (!product) {
            req.flash('error', 'Product not found.');
            return res.redirect('/products');
        }
        const originalPrice = priceForCycle(product, cycle);
        if (!originalPrice || originalPrice <= 0) {
            req.flash('error', 'This plan is not available on that billing cycle.');
            return res.redirect(`/products/${productId}`);
        }
        const user = await dbGet('SELECT coins FROM users WHERE id = ?', [userId]);
        let discount = 0;
        let appliedCode = '';
        if (couponCode && String(couponCode).trim()) {
            const code = helpers.sanitize(couponCode).toUpperCase();
            const coupon = await dbGet(
                `SELECT * FROM coupons WHERE code = ? AND isActive = 1
                 AND (expiresAt IS NULL OR expiresAt > datetime('now'))
                 AND (maxUses IS NULL OR uses < maxUses)`,
                [code]
            );
            if (!coupon) {
                req.flash('error', 'That coupon is invalid or has expired.');
                return res.redirect(`/products/${productId}?cycle=${cycle}`);
            }
            discount = coupon.couponType === 'percent'
                ? Math.round(originalPrice * (Math.min(100, coupon.value) / 100))
                : Math.min(Math.round(coupon.value), originalPrice);
            appliedCode = code;
            await runDb('UPDATE coupons SET uses = uses + 1 WHERE id = ?', [coupon.id]);
        }
        const total = Math.max(0, originalPrice - discount);
        if (!user || user.coins < total) {
            req.flash('error', `Not enough ${res.locals.currencyName}. You need ${total} coins but have ${user ? user.coins : 0}. Top up your wallet to continue.`);
            return res.redirect('/store');
        }
        await runDb('UPDATE users SET coins = coins - ? WHERE id = ?', [total, userId]);
        const orderId = uuidv4();
        const note = await helpers.getRandomNote(product.id);
        await runDb(
            `INSERT INTO orders (id, userId, productId, productName, productCategory, billingCycle, originalPrice, discount, price, note, paymentMethod, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'coins', 'active')`,
            [orderId, userId, product.id, product.name, product.categoryName || 'Hosting', cycle, originalPrice, discount, total, note]
        );
        req.session.user.coins = user.coins - total;
        req.flash('success', `${product.name} is live! ${appliedCode ? `Coupon ${appliedCode} applied. ` : ''}Your order details are below.`);
        res.redirect(`/orders/${orderId}`);
    } catch (err) { next(err); }
});

app.get('/orders', requireAuth, async (req, res, next) => {
    try {
        const userId = req.session.user.id;
        const page = Math.max(1, parseInt(req.query.page, 10) || 1);
        const perPage = 8;
        const status = ['all', 'active', 'pending', 'suspended', 'cancelled', 'completed'].includes(req.query.status) ? req.query.status : 'all';
        const whereStatus = status === 'all' ? '' : ' AND status = ?';
        const params = [userId, ...(status === 'all' ? [] : [status])];
        const countRow = await dbGet(`SELECT COUNT(*) AS c FROM orders WHERE userId = ?${whereStatus}`, params);
        const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
        const orders = await dbAll(
            `SELECT * FROM orders WHERE userId = ?${whereStatus} ORDER BY createdAt DESC LIMIT ? OFFSET ?`,
            [...params, perPage, (pagination.page - 1) * perPage]
        );
        res.render('users/orders', {
            ...pageMeta('My orders', 'orders'),
            orders,
            pagination,
            status
        });
    } catch (err) { next(err); }
});

app.get('/orders/:id', requireAuth, async (req, res, next) => {
    try {
        const order = await dbGet('SELECT * FROM orders WHERE id = ? AND userId = ?', [req.params.id, req.session.user.id]);
        if (!order) {
            req.flash('error', 'Order not found.');
            return res.redirect('/orders');
        }
        const product = await getProduct(order.productId);
        const renews = order.status === 'active' || order.status === 'suspended'
            ? moment(order.createdAt).add(helpers.cycleMonths(order.billingCycle), 'months').format('DD MMM YYYY')
            : null;
        res.render('users/order-detail', {
            ...pageMeta(`Order ${order.productName}`, 'orders'),
            order,
            product,
            renews
        });
    } catch (err) { next(err); }
});

app.get('/orders/:id/invoice', requireAuth, async (req, res, next) => {
    try {
        const order = await dbGet('SELECT * FROM orders WHERE id = ? AND userId = ?', [req.params.id, req.session.user.id]);
        if (!order) {
            req.flash('error', 'Order not found.');
            return res.redirect('/orders');
        }
        const product = await getProduct(order.productId);
        res.render('users/invoice', {
            ...pageMeta('Invoice', 'orders'),
            order,
            product
        });
    } catch (err) { next(err); }
});

// =========================================================
//  DASHBOARD
// =========================================================
app.get('/dashboard', requireAuth, async (req, res, next) => {
    try {
        const userId = req.session.user.id;
        const [orders, totalOrders, openTickets, activeServices, spentRow, tickets, likedRows] = await Promise.all([
            dbAll('SELECT * FROM orders WHERE userId = ? ORDER BY createdAt DESC LIMIT 5', [userId]),
            helpers.countRows('orders', 'WHERE userId = ?', [userId]),
            helpers.countRows('tickets', 'WHERE userId = ? AND status IN ("open","in_progress","on_hold")', [userId]),
            helpers.countRows('orders', 'WHERE userId = ? AND status = "active"', [userId]),
            dbGet('SELECT SUM(price) AS total FROM orders WHERE userId = ? AND status != "cancelled"', [userId]),
            dbAll('SELECT * FROM tickets WHERE userId = ? ORDER BY updatedAt DESC LIMIT 3', [userId]),
            dbAll(`SELECT p.*, c.name AS categoryName, c.slug AS categorySlug, c.icon AS categoryIcon, c.accent AS categoryAccent
                   FROM likes l JOIN products p ON l.productId = p.id
                   LEFT JOIN categories c ON p.categoryId = c.id
                   WHERE l.userId = ? AND p.isActive = 1 ORDER BY l.createdAt DESC LIMIT 3`, [userId])
        ]);
        const liked = await processProducts(likedRows);
        const unreadTickets = await helpers.countRows('tickets', 'WHERE userId = ? AND isReadUser = 0', [userId]);
        res.render('users/dashboard', {
            ...pageMeta('Dashboard', 'dashboard'),
            orders,
            tickets,
            liked,
            stats: {
                totalOrders,
                openTickets,
                activeServices,
                spent: spentRow && spentRow.total ? spentRow.total : 0,
                unreadTickets
            },
            renewals: orders.filter((o) => o.status === 'active').length
        });
    } catch (err) { next(err); }
});

// =========================================================
//  PROFILE
// =========================================================
app.get('/profile', requireAuth, async (req, res, next) => {
    try {
        const profileUser = await dbGet('SELECT * FROM users WHERE id = ?', [req.session.user.id]);
        const stats = {
            orders: await helpers.countRows('orders', 'WHERE userId = ?', [req.session.user.id]),
            tickets: await helpers.countRows('tickets', 'WHERE userId = ?', [req.session.user.id])
        };
        res.render('users/profile', {
            ...pageMeta('My profile', 'profile'),
            profileUser,
            stats
        });
    } catch (err) { next(err); }
});

app.post('/profile', requireAuth, async (req, res, next) => {
    try {
        const { firstName, lastName, phone, address, city, state, postalCode } = req.body;
        if (!firstName || !lastName) {
            req.flash('error', 'First and last name are required.');
            return res.redirect('/profile');
        }
        await runDb(
            `UPDATE users SET firstName = ?, lastName = ?, phone = ?, address = ?, city = ?, state = ?, postalCode = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?`,
            [helpers.sanitize(firstName), helpers.sanitize(lastName), helpers.sanitize(phone || ''), helpers.sanitize(address || ''), helpers.sanitize(city || ''), helpers.sanitize(state || ''), helpers.sanitize(postalCode || ''), req.session.user.id]
        );
        req.flash('success', 'Profile updated.');
        res.redirect('/profile');
    } catch (err) { next(err); }
});

app.get('/profile/security', requireAuth, (req, res) => {
    res.render('users/security', {
        ...pageMeta('Password & security', 'security')
    });
});

app.post('/profile/security', requireAuth, async (req, res, next) => {
    try {
        const { currentPassword, newPassword, confirmPassword } = req.body;
        if (!newPassword || newPassword.length < 8) {
            req.flash('error', 'Your new password must be at least 8 characters.');
            return res.redirect('/profile/security');
        }
        if (newPassword !== confirmPassword) {
            req.flash('error', 'The new passwords do not match.');
            return res.redirect('/profile/security');
        }
        const user = await dbGet('SELECT password FROM users WHERE id = ?', [req.session.user.id]);
        if (!bcrypt.compareSync(String(currentPassword || ''), user.password)) {
            req.flash('error', 'Your current password is incorrect.');
            return res.redirect('/profile/security');
        }
        await runDb('UPDATE users SET password = ?, updatedAt = CURRENT_TIMESTAMP WHERE id = ?', [bcrypt.hashSync(newPassword, 10), req.session.user.id]);
        req.flash('success', 'Password updated. Use it next time you sign in.');
        res.redirect('/profile/security');
    } catch (err) { next(err); }
});

// =========================================================
//  TICKETS
// =========================================================
app.get('/tickets', requireAuth, async (req, res, next) => {
    try {
        const userId = req.session.user.id;
        const page = Math.max(1, parseInt(req.query.page, 10) || 1);
        const perPage = 8;
        const status = req.query.status || 'all';
        const search = helpers.sanitize(req.query.search || '');
        let where = 'WHERE userId = ?';
        const params = [userId];
        if (status !== 'all' && TICKET_CONFIG.STATUSES.includes(status)) {
            where += ' AND status = ?';
            params.push(status);
        }
        if (search) {
            where += ' AND (subject LIKE ? OR id LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }
        const countRow = await dbGet(`SELECT COUNT(*) AS c FROM tickets ${where}`, params);
        const pagination = helpers.paginate(countRow ? countRow.c : 0, page, perPage);
        const tickets = await dbAll(`SELECT * FROM tickets ${where} ORDER BY updatedAt DESC LIMIT ? OFFSET ?`, [...params, perPage, (pagination.page - 1) * perPage]);
        const unread = await helpers.countRows('tickets', 'WHERE userId = ? AND isReadUser = 0', [userId]);
        const openCount = await helpers.countRows('tickets', 'WHERE userId = ? AND status IN ("open","in_progress","on_hold")', [userId]);
        res.render('users/tickets', {
            ...pageMeta('Support tickets', 'tickets'),
            tickets,
            pagination,
            status,
            search,
            unread,
            openCount
        });
    } catch (err) { next(err); }
});

app.get('/tickets/new', requireAuth, (req, res) => {
    res.render('users/ticket-new', {
        ...pageMeta('Open a ticket', 'tickets'),
        formData: {}
    });
});

app.post('/tickets', requireAuth, ticketUpload.array('attachments', TICKET_CONFIG.MAX_ATTACHMENTS), async (req, res, next) => {
    try {
        const { subject, message, department, priority, tags } = req.body;
        const errors = [];
        if (!subject || subject.trim().length < 4) errors.push('Give your ticket a clear subject (4+ characters).');
        if (!message || message.trim().length < 10) errors.push('Describe the issue in a little more detail (10+ characters).');
        if (!TICKET_CONFIG.DEPARTMENTS.includes(department)) errors.push('Choose a valid department.');
        if (!TICKET_CONFIG.PRIORITIES.includes(priority)) errors.push('Choose a valid priority.');
        if (errors.length) {
            errors.forEach((e) => req.flash('error', e));
            return res.redirect('/tickets/new');
        }
        const id = 'TKT-' + uuidv4().split('-')[0].toUpperCase();
        const attachments = (req.files || []).map((f) => ({ name: f.originalname, path: `/uploads/${f.filename}`, size: f.size, type: f.mimetype }));
        const cleanTags = String(tags || '').split(',').map((t) => t.trim()).filter((t) => TICKET_CONFIG.TAGS.includes(t));
        await runDb(
            `INSERT INTO tickets (id, userId, subject, description, department, priority, status, tags, isReadUser, isReadAdmin, slaDue)
             VALUES (?, ?, ?, ?, ?, ?, 'open', ?, 1, 0, ?)`,
            [id, req.session.user.id, helpers.sanitize(subject), helpers.sanitize(message).slice(0, 200), department, priority, cleanTags.join(','), calculateSLADueDate(priority)]
        );
        await runDb(
            `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments, isAdminReply, isNote) VALUES (?, ?, ?, ?, ?, 0, 0)`,
            [uuidv4(), id, req.session.user.id, helpers.sanitize(message), JSON.stringify(attachments)]
        );
        req.flash('success', `Ticket ${id} opened. Our team will reply shortly.`);
        res.redirect(`/tickets/${id}`);
    } catch (err) { next(err); }
});

app.get('/tickets/:id', requireAuth, async (req, res, next) => {
    try {
        const ticket = await dbGet('SELECT * FROM tickets WHERE id = ? AND userId = ?', [req.params.id, req.session.user.id]);
        if (!ticket) {
            req.flash('error', 'Ticket not found.');
            return res.redirect('/tickets');
        }
        await runDb('UPDATE tickets SET isReadUser = 1 WHERE id = ?', [ticket.id]);
        const replies = await dbAll(
            `SELECT tr.*, u.firstName, u.lastName, u.isAdmin FROM ticket_replies tr
             LEFT JOIN users u ON tr.userId = u.id
             WHERE tr.ticketId = ? AND tr.isNote = 0 ORDER BY tr.createdAt ASC`,
            [ticket.id]
        );
        replies.forEach((r) => {
            try { r.attachments = JSON.parse(r.attachments || '[]'); } catch (e) { r.attachments = []; }
        });
        const labels = TICKET_CONFIG.STATUSES.map((s) => s.replace('_', ' '));
        res.render('users/ticket-view', {
            ...pageMeta(ticket.subject, 'tickets'),
            ticket,
            replies,
            tags: ticket.tags ? ticket.tags.split(',') : [],
            sla: slaStatus(ticket),
            labels
        });
    } catch (err) { next(err); }
});

app.post('/tickets/:id/reply', requireAuth, ticketUpload.array('attachments', TICKET_CONFIG.MAX_ATTACHMENTS), async (req, res, next) => {
    try {
        const ticket = await dbGet('SELECT * FROM tickets WHERE id = ? AND userId = ?', [req.params.id, req.session.user.id]);
        if (!ticket) {
            req.flash('error', 'Ticket not found.');
            return res.redirect('/tickets');
        }
        if (ticket.status === 'closed') {
            req.flash('error', 'This ticket is closed. Open a new one if you still need help.');
            return res.redirect(`/tickets/${ticket.id}`);
        }
        if (!req.body.message || req.body.message.trim().length < 2) {
            req.flash('error', 'Write a message before sending.');
            return res.redirect(`/tickets/${ticket.id}`);
        }
        const attachments = (req.files || []).map((f) => ({ name: f.originalname, path: `/uploads/${f.filename}`, size: f.size, type: f.mimetype }));
        await runDb(
            `INSERT INTO ticket_replies (id, ticketId, userId, message, attachments) VALUES (?, ?, ?, ?, ?)`,
            [uuidv4(), ticket.id, req.session.user.id, helpers.sanitize(req.body.message), JSON.stringify(attachments)]
        );
        await runDb(
            `UPDATE tickets SET updatedAt = CURRENT_TIMESTAMP, isReadUser = 1, isReadAdmin = 0, status = CASE WHEN status = 'resolved' THEN 'open' ELSE status END WHERE id = ?`,
            [ticket.id]
        );
        req.flash('success', 'Reply sent to the support team.');
        res.redirect(`/tickets/${ticket.id}`);
    } catch (err) { next(err); }
});

app.post('/tickets/:id/close', requireAuth, async (req, res, next) => {
    try {
        const ticket = await dbGet('SELECT * FROM tickets WHERE id = ? AND userId = ?', [req.params.id, req.session.user.id]);
        if (!ticket) {
            req.flash('error', 'Ticket not found.');
            return res.redirect('/tickets');
        }
        await runDb(`UPDATE tickets SET status = 'closed', updatedAt = CURRENT_TIMESTAMP WHERE id = ?`, [ticket.id]);
        req.flash('success', 'Ticket closed. Glad we could help!');
        res.redirect(`/tickets/${ticket.id}`);
    } catch (err) { next(err); }
});

// =========================================================
//  ADMIN ROUTES  (views live in views/admin/*)
// =========================================================
require('./routes/admin')(app, {
    dbGet, dbAll, runDb, helpers,
    getProduct, processProducts, getCategoryBySlug,
    requireAdmin, upload, categoryUpload, upsertSetting,
    uuidv4, moment, bcrypt, TICKET_CONFIG,
    calculateSLADueDate, slaStatus,
    COIN_ICON
});

// =========================================================
//  COUPON VALIDATION (used by product page JS)
// =========================================================
app.post('/api/coupon', async (req, res) => {
    try {
        const { code, productId, cycle } = req.body || {};
        const product = await getProduct(productId);
        if (!product) return res.json({ ok: false, error: 'Product not found.' });
        const billingCycle = ['monthly', 'quarterly', 'yearly'].includes(cycle) ? cycle : 'monthly';
        const price = priceForCycle(product, billingCycle);
        const cleanCode = helpers.sanitize(code || '').toUpperCase();
        if (!cleanCode) return res.json({ ok: false, error: 'Enter a coupon code.' });
        const coupon = await dbGet(
            `SELECT * FROM coupons WHERE code = ? AND isActive = 1
             AND (expiresAt IS NULL OR expiresAt > datetime('now'))
             AND (maxUses IS NULL OR uses < maxUses)`,
            [cleanCode]
        );
        if (!coupon) return res.json({ ok: false, error: 'That code is invalid or has expired.' });
        const discount = coupon.couponType === 'percent'
            ? Math.round(price * (Math.min(100, coupon.value) / 100))
            : Math.min(Math.round(coupon.value), price);
        return res.json({
            ok: true,
            code: coupon.code,
            type: coupon.couponType,
            value: coupon.value,
            discount,
            total: Math.max(0, price - discount),
            label: coupon.couponType === 'percent'
                ? `Code applied — ${coupon.value}% off this order.`
                : `Code applied — ${coupon.value} coins off this order.`
        });
    } catch (err) {
        console.error('Coupon check error:', err);
        return res.status(500).json({ ok: false, error: 'Could not verify that code.' });
    }
});

// =========================================================
//  MISC PAGES
// =========================================================
app.get('/legal', (req, res) => {
    res.render('users/legal', { ...pageMeta('Policies', 'legal') });
});

app.get('/maintenance', (req, res) => {
    res.status(res.locals.maintenanceMode ? 503 : 200).render('maintenance', { ...pageMeta('Scheduled maintenance', ''), hideCta: true });
});

// ---------- search overlay fallback ----------
app.get('/search', (req, res) => res.redirect(`/products?search=${encodeURIComponent(req.query.q || '')}`));

// ---------- 404 / 500 ----------
app.use((req, res) => {
    res.status(404).render('errors/404', { ...pageMeta('Page not found', '') });
});

app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    if (res.headersSent) return next(err);
    if (req.path.startsWith('/api')) return res.status(500).json({ error: 'Server error' });
    res.status(500).render('errors/500', { ...pageMeta('Something went wrong', '') });
});

// =========================================================
//  START
// =========================================================
(async () => {
    await createSchema();
    await seed();
    app.listen(PORT, '0.0.0.0', () => {
        console.log('');
        console.log('  SiftNodes — user area');
        console.log(`  Running at http://localhost:${PORT}`);
        console.log(`  Demo account: demo@unixservice.in / password123`);
        console.log(`  Demo mode (auto-credit coin top-ups): ${DEMO_MODE ? 'ON' : 'OFF'}`);
        console.log('');
    });
})();
